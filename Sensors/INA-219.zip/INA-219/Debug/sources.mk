################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Application/User/Core \
Application/User/Startup \
Drivers/CMSIS \
Drivers/STM32F4xx_HAL_Driver \
hmc5883L_magnetometer/Core/Src \
hmc5883L_magnetometer/Core/Startup \
hmc5883L_magnetometer/Debug/Core/Src \
hmc5883L_magnetometer/Debug/Core/Startup \
hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src \
hmc5883L_magnetometer/Debug \
hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src \

