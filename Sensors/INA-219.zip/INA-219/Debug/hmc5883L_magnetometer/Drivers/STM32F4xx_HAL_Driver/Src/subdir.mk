################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.c \
../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.c 

OBJS += \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.o \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.o 

C_DEPS += \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.d \
./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.d 


# Each subdirectory must supply rules for building sources it contributes
hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/%.o hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/%.su hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/%.cyclo: ../hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/%.c hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../../Core/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-hmc5883L_magnetometer-2f-Drivers-2f-STM32F4xx_HAL_Driver-2f-Src

clean-hmc5883L_magnetometer-2f-Drivers-2f-STM32F4xx_HAL_Driver-2f-Src:
	-$(RM) ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.su ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.cyclo ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.d ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.o ./hmc5883L_magnetometer/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.su

.PHONY: clean-hmc5883L_magnetometer-2f-Drivers-2f-STM32F4xx_HAL_Driver-2f-Src

