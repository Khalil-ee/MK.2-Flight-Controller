################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../hmc5883L_magnetometer/Core/Src/main.c \
../hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.c \
../hmc5883L_magnetometer/Core/Src/stm32f4xx_it.c \
../hmc5883L_magnetometer/Core/Src/syscalls.c \
../hmc5883L_magnetometer/Core/Src/sysmem.c \
../hmc5883L_magnetometer/Core/Src/system_stm32f4xx.c 

OBJS += \
./hmc5883L_magnetometer/Core/Src/main.o \
./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.o \
./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.o \
./hmc5883L_magnetometer/Core/Src/syscalls.o \
./hmc5883L_magnetometer/Core/Src/sysmem.o \
./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.o 

C_DEPS += \
./hmc5883L_magnetometer/Core/Src/main.d \
./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.d \
./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.d \
./hmc5883L_magnetometer/Core/Src/syscalls.d \
./hmc5883L_magnetometer/Core/Src/sysmem.d \
./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.d 


# Each subdirectory must supply rules for building sources it contributes
hmc5883L_magnetometer/Core/Src/%.o hmc5883L_magnetometer/Core/Src/%.su hmc5883L_magnetometer/Core/Src/%.cyclo: ../hmc5883L_magnetometer/Core/Src/%.c hmc5883L_magnetometer/Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../../Core/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc -I../../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-hmc5883L_magnetometer-2f-Core-2f-Src

clean-hmc5883L_magnetometer-2f-Core-2f-Src:
	-$(RM) ./hmc5883L_magnetometer/Core/Src/main.cyclo ./hmc5883L_magnetometer/Core/Src/main.d ./hmc5883L_magnetometer/Core/Src/main.o ./hmc5883L_magnetometer/Core/Src/main.su ./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.cyclo ./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.d ./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.o ./hmc5883L_magnetometer/Core/Src/stm32f4xx_hal_msp.su ./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.cyclo ./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.d ./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.o ./hmc5883L_magnetometer/Core/Src/stm32f4xx_it.su ./hmc5883L_magnetometer/Core/Src/syscalls.cyclo ./hmc5883L_magnetometer/Core/Src/syscalls.d ./hmc5883L_magnetometer/Core/Src/syscalls.o ./hmc5883L_magnetometer/Core/Src/syscalls.su ./hmc5883L_magnetometer/Core/Src/sysmem.cyclo ./hmc5883L_magnetometer/Core/Src/sysmem.d ./hmc5883L_magnetometer/Core/Src/sysmem.o ./hmc5883L_magnetometer/Core/Src/sysmem.su ./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.cyclo ./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.d ./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.o ./hmc5883L_magnetometer/Core/Src/system_stm32f4xx.su

.PHONY: clean-hmc5883L_magnetometer-2f-Core-2f-Src

