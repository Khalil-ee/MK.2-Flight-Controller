hmc5883L_magnetometer/Core/Src/sysmem.o: \
 ../hmc5883L_magnetometer/Core/Src/sysmem.c
