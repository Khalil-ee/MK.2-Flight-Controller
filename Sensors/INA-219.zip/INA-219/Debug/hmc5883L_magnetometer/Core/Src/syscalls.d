hmc5883L_magnetometer/Core/Src/syscalls.o: \
 ../hmc5883L_magnetometer/Core/Src/syscalls.c
