hmc5883L_magnetometer/Core/Startup/startup_stm32f446retx.o: \
 ../hmc5883L_magnetometer/Core/Startup/startup_stm32f446retx.s
