################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
O_SRCS += \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_cortex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_dma_ex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_exti.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_flash_ramfunc.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_gpio.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_i2c_ex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_pwr_ex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_rcc_ex.o \
../hmc5883L_magnetometer/Debug/Drivers/STM32F4xx_HAL_Driver/Src/stm32f4xx_hal_uart.o 


# Each subdirectory must supply rules for building sources it contributes

