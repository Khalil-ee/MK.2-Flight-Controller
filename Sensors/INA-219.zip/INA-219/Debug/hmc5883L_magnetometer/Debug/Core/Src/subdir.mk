################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
O_SRCS += \
../hmc5883L_magnetometer/Debug/Core/Src/main.o \
../hmc5883L_magnetometer/Debug/Core/Src/stm32f4xx_hal_msp.o \
../hmc5883L_magnetometer/Debug/Core/Src/stm32f4xx_it.o \
../hmc5883L_magnetometer/Debug/Core/Src/syscalls.o \
../hmc5883L_magnetometer/Debug/Core/Src/sysmem.o \
../hmc5883L_magnetometer/Debug/Core/Src/system_stm32f4xx.o 


# Each subdirectory must supply rules for building sources it contributes

