/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : QMC5883P Magnetometer Test with STM32 Nucleo-F446RE
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/*
   Your I2C scanner found address 0x2C.
   This means the module is most likely QMC5883P, not a real HMC5883L.

   STM32 HAL requires the 7-bit I2C address shifted left by 1.
*/
#define QMC5883P_ADDR          (0x2C << 1)

// QMC5883P register map
#define QMC5883P_REG_X_LSB     0x01
#define QMC5883P_REG_X_MSB     0x02
#define QMC5883P_REG_Y_LSB     0x03
#define QMC5883P_REG_Y_MSB     0x04
#define QMC5883P_REG_Z_LSB     0x05
#define QMC5883P_REG_Z_MSB     0x06
#define QMC5883P_REG_STATUS    0x09
#define QMC5883P_REG_CTRL1     0x0A
#define QMC5883P_REG_CTRL2     0x0B

// I2C pins for your setup
#define I2C_SCL_GPIO_PORT      GPIOB
#define I2C_SCL_PIN            GPIO_PIN_8
#define I2C_SDA_GPIO_PORT      GPIOB
#define I2C_SDA_PIN            GPIO_PIN_9

// Raw magnetometer values
int16_t Mag_X_RAW = 0;
int16_t Mag_Y_RAW = 0;
int16_t Mag_Z_RAW = 0;

// Approximate converted values
int32_t Mag_X_mG = 0;
int32_t Mag_Y_mG = 0;
int32_t Mag_Z_mG = 0;

// Heading values
float heading_rad = 0.0f;
float heading_deg = 0.0f;

// Approximate scale for bring-up testing
#define QMC5883P_LSB_PER_GAUSS 1000

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
void debug_print(char *msg);
void I2C_Scan(void);
void I2C_BusRecovery(void);

uint8_t QMC5883P_CheckDevice(void);
uint8_t QMC5883P_WriteReg(uint8_t reg, uint8_t value);
uint8_t QMC5883P_ReadReg(uint8_t reg, uint8_t *value);
uint8_t QMC5883P_Init(void);
uint8_t QMC5883P_ReadMagnetometer(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

void debug_print(char *msg)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 500);
}

void I2C_Scan(void)
{
    char buffer[100];

    debug_print("Scanning I2C bus...\r\n");

    for (uint8_t addr = 1; addr < 128; addr++)
    {
        if (HAL_I2C_IsDeviceReady(&hi2c1, addr << 1, 2, 20) == HAL_OK)
        {
            sprintf(buffer, "I2C device found at 0x%02X\r\n", addr);
            debug_print(buffer);
        }
    }

    debug_print("I2C scan done\r\n");
}

void I2C_BusRecovery(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    debug_print("Attempting I2C bus recovery...\r\n");

    // Deinitialize I2C peripheral
    HAL_I2C_DeInit(&hi2c1);
    HAL_Delay(10);

    // Configure PB8 and PB9 as open-drain GPIO outputs
    GPIO_InitStruct.Pin = I2C_SCL_PIN | I2C_SDA_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Release both lines high
    HAL_GPIO_WritePin(I2C_SCL_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(I2C_SDA_GPIO_PORT, I2C_SDA_PIN, GPIO_PIN_SET);
    HAL_Delay(5);

    // Pulse SCL 9 times to free a stuck slave
    for (int i = 0; i < 9; i++)
    {
        HAL_GPIO_WritePin(I2C_SCL_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_RESET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(I2C_SCL_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_SET);
        HAL_Delay(1);
    }

    // Generate a stop condition manually: SDA low then high while SCL high
    HAL_GPIO_WritePin(I2C_SDA_GPIO_PORT, I2C_SDA_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(I2C_SCL_GPIO_PORT, I2C_SCL_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(I2C_SDA_GPIO_PORT, I2C_SDA_PIN, GPIO_PIN_SET);
    HAL_Delay(5);

    // Reinitialize I2C peripheral
    MX_I2C1_Init();
    HAL_Delay(50);

    debug_print("I2C bus recovery complete\r\n");
}

uint8_t QMC5883P_CheckDevice(void)
{
    if (HAL_I2C_IsDeviceReady(&hi2c1, QMC5883P_ADDR, 3, 500) == HAL_OK)
    {
        return 1;
    }

    return 0;
}

uint8_t QMC5883P_WriteReg(uint8_t reg, uint8_t value)
{
    HAL_StatusTypeDef status;

    status = HAL_I2C_Mem_Write(&hi2c1, QMC5883P_ADDR, reg, 1, &value, 1, 500);

    if (status == HAL_OK)
    {
        return 1;
    }

    return 0;
}

uint8_t QMC5883P_ReadReg(uint8_t reg, uint8_t *value)
{
    HAL_StatusTypeDef status;

    status = HAL_I2C_Mem_Read(&hi2c1, QMC5883P_ADDR, reg, 1, value, 1, 500);

    if (status == HAL_OK)
    {
        return 1;
    }

    return 0;
}

uint8_t QMC5883P_Init(void)
{
    uint8_t status_reg = 0;
    char buffer[120];

    /*
       This code avoids the extra reset/setup register because your board did
       not like that write.

       CTRL2 and CTRL1 are enough for basic bring-up testing.
    */

    /*
       CTRL2:
       0x0C is commonly used for QMC5883P setup.
    */
    if (!QMC5883P_WriteReg(QMC5883P_REG_CTRL2, 0x0C))
    {
        debug_print("Failed to write QMC5883P CTRL2\r\n");
        return 0;
    }

    HAL_Delay(100);

    /*
       CTRL1:
       0xC3 is a gentler/slower setup than 0xCF.
       This may be more stable for breadboard wiring.
    */
    if (!QMC5883P_WriteReg(QMC5883P_REG_CTRL1, 0xC3))
    {
        debug_print("Failed to write QMC5883P CTRL1\r\n");
        return 0;
    }

    HAL_Delay(300);

    if (QMC5883P_ReadReg(QMC5883P_REG_STATUS, &status_reg))
    {
        sprintf(buffer, "QMC5883P status register = 0x%02X\r\n", status_reg);
        debug_print(buffer);
    }
    else
    {
        debug_print("Could not read QMC5883P status register after init\r\n");
        return 0;
    }

    debug_print("QMC5883P initialized\r\n");
    return 1;
}

uint8_t QMC5883P_ReadMagnetometer(void)
{
    uint8_t data[6];
    uint8_t status_reg;
    HAL_StatusTypeDef status;

    /*
       Try up to 3 times before declaring the read failed.
    */
    for (int attempt = 1; attempt <= 3; attempt++)
    {
        // Check if device is still responding
        if (!QMC5883P_CheckDevice())
        {
            HAL_Delay(50);
            continue;
        }

        // Read status register
        status = HAL_I2C_Mem_Read(&hi2c1, QMC5883P_ADDR, QMC5883P_REG_STATUS, 1, &status_reg, 1, 500);

        if (status != HAL_OK)
        {
            HAL_Delay(50);
            continue;
        }

        /*
           Read magnetic data:
           0x01 = X LSB
           0x02 = X MSB
           0x03 = Y LSB
           0x04 = Y MSB
           0x05 = Z LSB
           0x06 = Z MSB
        */
        status = HAL_I2C_Mem_Read(&hi2c1, QMC5883P_ADDR, QMC5883P_REG_X_LSB, 1, data, 6, 500);

        if (status == HAL_OK)
        {
            Mag_X_RAW = (int16_t)((data[1] << 8) | data[0]);
            Mag_Y_RAW = (int16_t)((data[3] << 8) | data[2]);
            Mag_Z_RAW = (int16_t)((data[5] << 8) | data[4]);

            Mag_X_mG = ((int32_t)Mag_X_RAW * 1000) / QMC5883P_LSB_PER_GAUSS;
            Mag_Y_mG = ((int32_t)Mag_Y_RAW * 1000) / QMC5883P_LSB_PER_GAUSS;
            Mag_Z_mG = ((int32_t)Mag_Z_RAW * 1000) / QMC5883P_LSB_PER_GAUSS;

            /*
               Basic heading calculation using X and Y.
               This is not tilt-compensated yet.
            */
            heading_rad = atan2f((float)Mag_Y_RAW, (float)Mag_X_RAW);

            if (heading_rad < 0)
            {
                heading_rad += 2.0f * 3.14159265f;
            }

            heading_deg = heading_rad * 180.0f / 3.14159265f;

            return 1;
        }

        HAL_Delay(50);
    }

    return 0;
}

/* USER CODE END 0 */

int main(void)
{
    char buffer[220];
    uint8_t setup_ok = 0;
    uint8_t consecutive_failures = 0;

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART2_UART_Init();

    /* USER CODE BEGIN 2 */

    debug_print("Starting QMC5883P magnetometer test...\r\n");

    I2C_Scan();

    if (QMC5883P_CheckDevice())
    {
        debug_print("QMC5883P responded at address 0x2C\r\n");
    }
    else
    {
        debug_print("No I2C response at address 0x2C\r\n");
        debug_print("Check VCC, GND, SCL, SDA, and CubeMX I2C1 setup.\r\n");
    }

    if (QMC5883P_Init())
    {
        debug_print("QMC5883P setup complete\r\n");
        setup_ok = 1;
    }
    else
    {
        debug_print("QMC5883P setup failed\r\n");
        setup_ok = 0;
    }

    /* USER CODE END 2 */

    while (1)
    {
        /* USER CODE BEGIN 3 */

        if (!setup_ok)
        {
            debug_print("Retrying QMC5883P setup...\r\n");

            I2C_BusRecovery();

            if (QMC5883P_CheckDevice() && QMC5883P_Init())
            {
                debug_print("QMC5883P setup recovered\r\n");
                setup_ok = 1;
                consecutive_failures = 0;
            }
            else
            {
                debug_print("QMC5883P setup still failed\r\n");
                setup_ok = 0;
            }
        }
        else
        {
            if (QMC5883P_ReadMagnetometer())
            {
                int32_t heading_int = (int32_t)heading_deg;

                sprintf(buffer,
                        "Raw X:%d Y:%d Z:%d | mG X:%ld Y:%ld Z:%ld | Heading:%ld deg\r\n",
                        Mag_X_RAW,
                        Mag_Y_RAW,
                        Mag_Z_RAW,
                        Mag_X_mG,
                        Mag_Y_mG,
                        Mag_Z_mG,
                        heading_int);

                debug_print(buffer);

                consecutive_failures = 0;
            }
            else
            {
                consecutive_failures++;

                sprintf(buffer, "QMC5883P read failed. Consecutive failures: %d\r\n", consecutive_failures);
                debug_print(buffer);

                /*
                   Do not immediately reinitialize after one bad read.
                   Only recover after 3 consecutive failed reads.
                */
                if (consecutive_failures >= 3)
                {
                    debug_print("Too many read failures. Recovering I2C and reinitializing sensor...\r\n");
                    I2C_BusRecovery();
                    setup_ok = 0;
                    consecutive_failures = 0;
                }
            }
        }

        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
        HAL_Delay(1000);

        /* USER CODE END 3 */
    }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 16;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ = 2;
    RCC_OscInitStruct.PLL.PLLR = 2;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 100000;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;

    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

    GPIO_InitStruct.Pin = B1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = LD2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    __disable_irq();

    while (1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
