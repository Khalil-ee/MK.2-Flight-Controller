/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : MK2 Sensor Fusion + Live Viewer Stream
  *                   MPU6050 + HMC5883L + BMP180 + INA219
  *                   STM32F446RE Nucleo | Madgwick AHRS Filter
  *
  *  WHAT THIS DOES
  *    Reads all four sensors, runs the Madgwick filter, and streams the result
  *    over USART2 (ST-Link virtual COM port, 115200 8N1) in the line format used
  *    by MK2_Attitude_Viewer.html:
  *        A,roll,pitch,yaw          (deg)            30 times/second
  *        R,ax,ay,az,gx,gy,gz,mx,my,mz  (g, deg/s, uT)  30 times/second
  *        B,pressure_hPa,temp_C     (BMP180)          2 times/second
  *        V,bus_voltage_V           (INA219)          2 times/second
  *    Lines starting with '#' are comments the viewer ignores.
  *
  *  SETUP (same as your working Sensor Fusion project)
  *    I2C1: SCL=PB8, SDA=PB9, 100 kHz     USART2: PA2/PA3, 115200 8N1
  *    Paste this whole file over Core/Src/main.c.  No printf-float setting needed.
  *
  *  SWITCHES (see USER SETTINGS below)
  *    USE_MAG        1 = use magnetometer for yaw, 0 = gyro-only yaw (drifts)
  *    DEBUG_PRINT    1 = old human-readable printout instead of viewer stream
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    int16_t  AC1, AC2, AC3;
    uint16_t AC4, AC5, AC6;
    int16_t  B1, B2, MB, MC, MD;
} BMP180_Calib_t;

typedef struct {
    float x;   /* State estimate (filtered value)          */
    float P;   /* Estimate error covariance                */
    float Q;   /* Process noise                            */
    float R;   /* Measurement noise                        */
} KalmanAxis_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* ───────────────────────── USER SETTINGS ───────────────────────── */
#define USE_MAG             1       /* 1 = magnetometer fused (heading), 0 = IMU only   */
#define DEBUG_PRINT         0       /* 1 = readable text instead of viewer stream       */
#define VIEWER_PERIOD_MS    33      /* A + R lines  (~30 Hz)                            */
#define SLOW_PERIOD_MS      500     /* BMP180 + INA219 lines (2 Hz)                     */
#define GYRO_CAL_SAMPLES    300     /* keep board still for ~1 s at power-up            */

/* If yaw/roll looks twisted when USE_MAG=1, the magnetometer module is mounted with
   different axes than the MPU-6050. Change these three expressions (x,y,z = raw mag)
   e.g.  (y), (-x), (z)   until the compass rotates the right way.                    */
#define MAG_FX(x,y,z)       (x)
#define MAG_FY(x,y,z)       (y)
#define MAG_FZ(x,y,z)       (z)
/* ───────────────────────────────────────────────────────────────── */

/* ── I2C Device Addresses (7-bit << 1 for HAL) ── */
#define MPU6050_ADDR        (0x68 << 1)
#define HMC5883L_ADDR       (0x1E << 1)
#define BMP180_ADDR         (0x77 << 1)
#define INA219_ADDR         (0x40 << 1)
#define I2C_TO              20      /* ms timeout, so a missing sensor cannot hang the loop */

/* ── MPU-6050 Registers ── */
#define MPU_REG_SMPLRT_DIV  0x19
#define MPU_REG_CONFIG      0x1A
#define MPU_REG_GYRO_CFG    0x1B
#define MPU_REG_ACCEL_CFG   0x1C
#define MPU_REG_ACCEL_XOUT  0x3B
#define MPU_REG_PWR_MGMT_1  0x6B

/* ── HMC5883L Registers ── */
#define HMC_REG_CFG_A       0x00
#define HMC_REG_CFG_B       0x01
#define HMC_REG_MODE        0x02
#define HMC_REG_DATA_XH     0x03

/* ── BMP180 Registers ── */
#define BMP_REG_CALIB       0xAA
#define BMP_REG_CTRL        0xF4
#define BMP_REG_DATA        0xF6
#define BMP_CMD_TEMP        0x2E
#define BMP_CMD_PRESS       0x34
#define BMP_OSS             0

/* ── INA219 Registers ── */
#define INA_REG_CONFIG      0x00
#define INA_REG_BUS_V       0x02
#define INA_REG_POWER       0x03
#define INA_REG_CURRENT     0x04
#define INA_REG_CALIB       0x05

/* ── Madgwick / Kalman ── */
#define BETA                0.1f    /* higher = trusts accel/mag more, noisier */
#define MAG_KALMAN_Q        0.1f
#define MAG_KALMAN_R        5.0f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;   /* Madgwick quaternion */
static BMP180_Calib_t bmp_cal;
static int32_t bmp_B5;
static KalmanAxis_t mag_kx = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_ky = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_kz = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static float gbias_x = 0, gbias_y = 0, gbias_z = 0;         /* gyro bias, rad/s    */
static uint8_t mag_valid = 0;                               /* got a good mag read */
static float last_mx = 0, last_my = 0, last_mz = 0;         /* last good mag, uT   */
static uint32_t last_cyc = 0;                               /* DWT timestamp       */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
static void     I2C_WriteReg  (uint8_t dev, uint8_t reg, uint8_t val);
static void     I2C_ReadBurst (uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len);
static void     I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val);
static int16_t  I2C_ReadReg16 (uint8_t dev, uint8_t reg);

static void MPU6050_Init  (void);
static void HMC5883L_Init (void);
static void BMP180_Init   (void);
static void INA219_Init   (void);

static void MPU6050_Read  (float *ax, float *ay, float *az,
                            float *gx, float *gy, float *gz, float *temp_c);
static void HMC5883L_Read (float *mx, float *my, float *mz);
static void BMP180_Read   (float *temp_c, float *press_pa, float *alt_m);
static void INA219_Read   (float *voltage, float *current_mA, float *power_mW);

static void MadgwickUpdate    (float gx, float gy, float gz, float ax, float ay, float az,
                               float mx, float my, float mz, float dt);
static void MadgwickUpdateIMU (float gx, float gy, float gz, float ax, float ay, float az, float dt);
static void QuaternionToEuler (float *roll, float *pitch, float *yaw);
static float Kalman1D_Update  (KalmanAxis_t *k, float measurement);

static void uart_send   (const char *s, uint16_t n);
static char *put_str    (char *p, const char *s);
static char *put_fixed  (char *p, float v, int dec);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* printf -> UART (only used by DEBUG_PRINT and the banner) */
int __io_putchar(int ch)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

/* ── tiny integer-only number formatting (no printf-float setting needed) ── */
static char *put_str(char *p, const char *s) { while (*s) *p++ = *s++; return p; }

static char *put_fixed(char *p, float v, int dec)
{
    if (v != v) v = 0.0f;                       /* NaN guard */
    if (v < 0)  { v = -v; *p++ = '-'; }
    if (v > 2000000.0f) v = 2000000.0f;
    uint32_t scale = 1; for (int i = 0; i < dec; i++) scale *= 10;
    uint32_t n = (uint32_t)(v * (float)scale + 0.5f);
    uint32_t whole = n / scale, frac = n % scale;
    char t[12]; int k = 0;
    do { t[k++] = (char)('0' + whole % 10); whole /= 10; } while (whole);
    while (k) *p++ = t[--k];
    if (dec) {
        *p++ = '.';
        uint32_t div = scale / 10;
        for (int i = 0; i < dec; i++) { *p++ = (char)('0' + (frac / div) % 10); div /= 10; if (!div) div = 1; }
    }
    return p;
}

static void uart_send(const char *s, uint16_t n)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)s, n, 50);
}

/* ═════════════ I2C HELPERS (with timeouts) ═════════════ */
static void I2C_WriteReg(uint8_t dev, uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 2, I2C_TO);
}

static void I2C_ReadBurst(uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len)
{
    if (HAL_I2C_Master_Transmit(&hi2c1, dev, &reg, 1, I2C_TO) != HAL_OK) { memset(buf, 0, len); return; }
    if (HAL_I2C_Master_Receive (&hi2c1, dev, buf, len, I2C_TO) != HAL_OK) { memset(buf, 0, len); }
}

static void I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = {reg, (uint8_t)(val >> 8), (uint8_t)(val & 0xFF)};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 3, I2C_TO);
}

static int16_t I2C_ReadReg16(uint8_t dev, uint8_t reg)
{
    uint8_t buf[2] = {0};
    I2C_ReadBurst(dev, reg, buf, 2);
    return (int16_t)((buf[0] << 8) | buf[1]);
}

/* ═════════════ MPU-6050 (Accel ±2 g, Gyro ±500 deg/s) ═════════════ */
static void MPU6050_Init(void)
{
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_PWR_MGMT_1, 0x00);
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_SMPLRT_DIV, 0x07);   /* 125 Hz                     */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_CONFIG,     0x03);   /* DLPF ~44 Hz (was 5 Hz: too laggy for live animation) */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_GYRO_CFG,   0x08);   /* +-500 deg/s                */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_ACCEL_CFG,  0x00);   /* +-2 g                      */
}

static void MPU6050_Read(float *ax, float *ay, float *az,
                         float *gx, float *gy, float *gz, float *temp_c)
{
    uint8_t buf[14];
    I2C_ReadBurst(MPU6050_ADDR, MPU_REG_ACCEL_XOUT, buf, 14);

    int16_t rax = (int16_t)((buf[0]  << 8) | buf[1]);
    int16_t ray = (int16_t)((buf[2]  << 8) | buf[3]);
    int16_t raz = (int16_t)((buf[4]  << 8) | buf[5]);
    int16_t rt  = (int16_t)((buf[6]  << 8) | buf[7]);
    int16_t rgx = (int16_t)((buf[8]  << 8) | buf[9]);
    int16_t rgy = (int16_t)((buf[10] << 8) | buf[11]);
    int16_t rgz = (int16_t)((buf[12] << 8) | buf[13]);

    *ax = rax / 16384.0f;  *ay = ray / 16384.0f;  *az = raz / 16384.0f;
    *temp_c = (rt / 340.0f) + 36.53f;
    *gx = (rgx / 65.5f) * (float)M_PI / 180.0f;     /* rad/s */
    *gy = (rgy / 65.5f) * (float)M_PI / 180.0f;
    *gz = (rgz / 65.5f) * (float)M_PI / 180.0f;
}

/* ═════════════ HMC5883L (1.3 Ga, 1090 LSB/Gauss) ═════════════ */
static void HMC5883L_Init(void)
{
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_A, 0x70);   /* 8 avg, 15 Hz */
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_B, 0x20);
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_MODE,  0x00);   /* continuous   */
}

static void HMC5883L_Read(float *mx, float *my, float *mz)
{
    uint8_t buf[6];
    I2C_ReadBurst(HMC5883L_ADDR, HMC_REG_DATA_XH, buf, 6);

    /* register order: XH XL ZH ZL YH YL */
    int16_t rx = (int16_t)((buf[0] << 8) | buf[1]);
    int16_t rz = (int16_t)((buf[2] << 8) | buf[3]);
    int16_t ry = (int16_t)((buf[4] << 8) | buf[5]);

    /* all zero = failed read, -4096 = saturated: keep last good value */
    if ((rx == 0 && ry == 0 && rz == 0) || rx == -4096 || ry == -4096 || rz == -4096) {
        *mx = last_mx; *my = last_my; *mz = last_mz;
        return;
    }
    float x = rx / 1090.0f * 100.0f;      /* -> uT */
    float y = ry / 1090.0f * 100.0f;
    float z = rz / 1090.0f * 100.0f;

    float fx = MAG_FX(x, y, z), fy = MAG_FY(x, y, z), fz = MAG_FZ(x, y, z);
    last_mx = *mx = Kalman1D_Update(&mag_kx, fx);
    last_my = *my = Kalman1D_Update(&mag_ky, fy);
    last_mz = *mz = Kalman1D_Update(&mag_kz, fz);
    mag_valid = 1;
}

static float Kalman1D_Update(KalmanAxis_t *k, float z)
{
    float P_pred = k->P + k->Q;
    float K = P_pred / (P_pred + k->R);
    k->x = k->x + K * (z - k->x);
    k->P = (1.0f - K) * P_pred;
    return k->x;
}

/* ═════════════ BMP180 ═════════════ */
static void BMP180_Init(void)
{
    uint8_t buf[22];
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_CALIB, buf, 22);
    bmp_cal.AC1 = (int16_t) ((buf[0]  << 8) | buf[1]);
    bmp_cal.AC2 = (int16_t) ((buf[2]  << 8) | buf[3]);
    bmp_cal.AC3 = (int16_t) ((buf[4]  << 8) | buf[5]);
    bmp_cal.AC4 = (uint16_t)((buf[6]  << 8) | buf[7]);
    bmp_cal.AC5 = (uint16_t)((buf[8]  << 8) | buf[9]);
    bmp_cal.AC6 = (uint16_t)((buf[10] << 8) | buf[11]);
    bmp_cal.B1  = (int16_t) ((buf[12] << 8) | buf[13]);
    bmp_cal.B2  = (int16_t) ((buf[14] << 8) | buf[15]);
    bmp_cal.MB  = (int16_t) ((buf[16] << 8) | buf[17]);
    bmp_cal.MC  = (int16_t) ((buf[18] << 8) | buf[19]);
    bmp_cal.MD  = (int16_t) ((buf[20] << 8) | buf[21]);
}

static void BMP180_Read(float *temp_c, float *press_pa, float *alt_m)
{
    uint8_t buf[3];

    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_TEMP);
    HAL_Delay(5);
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 2);
    int32_t UT = (int32_t)((buf[0] << 8) | buf[1]);

    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_PRESS | (BMP_OSS << 6));
    HAL_Delay(8);                                   /* OSS=0 needs 4.5 ms */
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 3);
    int32_t UP = (int32_t)(((buf[0] << 16) | (buf[1] << 8) | buf[2]) >> (8 - BMP_OSS));

    int32_t X1 = ((UT - (int32_t)bmp_cal.AC6) * (int32_t)bmp_cal.AC5) >> 15;
    int32_t den = X1 + (int32_t)bmp_cal.MD;
    if (den == 0) { *temp_c = 0; *press_pa = 0; *alt_m = 0; return; }   /* sensor missing */
    int32_t X2 = ((int32_t)bmp_cal.MC << 11) / den;
    bmp_B5 = X1 + X2;
    *temp_c = (float)((bmp_B5 + 8) >> 4) / 10.0f;

    int32_t B6 = bmp_B5 - 4000;
    X1 = ((int32_t)bmp_cal.B2 * ((B6 * B6) >> 12)) >> 11;
    X2 = ((int32_t)bmp_cal.AC2 * B6) >> 11;
    int32_t X3 = X1 + X2;
    int32_t B3 = (((((int32_t)bmp_cal.AC1 * 4) + X3) << BMP_OSS) + 2) >> 2;

    X1 = ((int32_t)bmp_cal.AC3 * B6) >> 13;
    X2 = ((int32_t)bmp_cal.B1 * ((B6 * B6) >> 12)) >> 16;
    X3 = ((X1 + X2) + 2) >> 2;
    uint32_t B4 = ((uint32_t)bmp_cal.AC4 * (uint32_t)(X3 + 32768)) >> 15;
    uint32_t B7 = ((uint32_t)UP - (uint32_t)B3) * (50000UL >> BMP_OSS);
    if (B4 == 0) { *press_pa = 0; *alt_m = 0; return; }

    int32_t p;
    if (B7 < 0x80000000UL) p = (int32_t)((B7 << 1) / B4);
    else                   p = (int32_t)((B7 / B4) << 1);

    X1 = (p >> 8) * (p >> 8);
    X1 = (X1 * 3038) >> 16;
    X2 = (-7357 * p) >> 16;
    p  = p + ((X1 + X2 + 3791) >> 4);

    *press_pa = (float)p;
    *alt_m = 44330.0f * (1.0f - powf(*press_pa / 101325.0f, 1.0f / 5.255f));
}

/* ═════════════ INA219 (100 ohm shunt, 32 V range) ═════════════ */
static void INA219_Init(void)
{
    I2C_WriteReg16(INA219_ADDR, INA_REG_CONFIG, 0x3FFF);
    I2C_WriteReg16(INA219_ADDR, INA_REG_CALIB,  0x1000);
}

static void INA219_Read(float *voltage, float *current_mA, float *power_mW)
{
    int16_t raw_bus = I2C_ReadReg16(INA219_ADDR, INA_REG_BUS_V);
    int16_t raw_cur = I2C_ReadReg16(INA219_ADDR, INA_REG_CURRENT);
    int16_t raw_pwr = I2C_ReadReg16(INA219_ADDR, INA_REG_POWER);
    *voltage    = (float)(raw_bus >> 3) * 0.004f;
    *current_mA = (float)raw_cur * 0.0001f;
    *power_mW   = (float)raw_pwr * 0.002f;
}

/* ═════════════ MADGWICK ═════════════
   Same math as your working version, but dt is now measured (the old fixed
   10 ms assumed no other code ever blocked the loop). */
static void MadgwickUpdate(float gx, float gy, float gz,
                           float ax, float ay, float az,
                           float mx, float my, float mz, float dt)
{
    float recipNorm, s0, s1, s2, s3, qDot1, qDot2, qDot3, qDot4, hx, hy;
    float _2q0mx, _2q0my, _2q0mz, _2q1mx, _2bx, _2bz, _4bx, _4bz;
    float _2q0, _2q1, _2q2, _2q3;
    float q0q0, q0q1, q0q2, q0q3, q1q1, q1q2, q1q3, q2q2, q2q3, q3q3;

    qDot1 = 0.5f * (-q1*gx - q2*gy - q3*gz);
    qDot2 = 0.5f * ( q0*gx + q2*gz - q3*gy);
    qDot3 = 0.5f * ( q0*gy - q1*gz + q3*gx);
    qDot4 = 0.5f * ( q0*gz + q1*gy - q2*gx);

    if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f)) &&
        !((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f)))
    {
        recipNorm = 1.0f / sqrtf(ax*ax + ay*ay + az*az);
        ax *= recipNorm; ay *= recipNorm; az *= recipNorm;
        recipNorm = 1.0f / sqrtf(mx*mx + my*my + mz*mz);
        mx *= recipNorm; my *= recipNorm; mz *= recipNorm;

        _2q0mx = 2.0f*q0*mx; _2q0my = 2.0f*q0*my; _2q0mz = 2.0f*q0*mz; _2q1mx = 2.0f*q1*mx;
        _2q0 = 2.0f*q0; _2q1 = 2.0f*q1; _2q2 = 2.0f*q2; _2q3 = 2.0f*q3;
        q0q0 = q0*q0; q0q1 = q0*q1; q0q2 = q0*q2; q0q3 = q0*q3;
        q1q1 = q1*q1; q1q2 = q1*q2; q1q3 = q1*q3;
        q2q2 = q2*q2; q2q3 = q2*q3; q3q3 = q3*q3;

        hx = mx*q0q0 - _2q0my*q3 + _2q0mz*q2 + mx*q1q1 + _2q1*my*q2 + _2q1*mz*q3 - mx*q2q2 - mx*q3q3;
        hy = _2q0mx*q3 + my*q0q0 - _2q0mz*q1 + _2q1mx*q2 - my*q1q1 + my*q2q2 + _2q2*mz*q3 - my*q3q3;
        _2bx = sqrtf(hx*hx + hy*hy);
        _2bz = -_2q0mx*q2 + _2q0my*q1 + mz*q0q0 + _2q1mx*q3 - mz*q1q1 + _2q2*my*q3 - mz*q2q2 + mz*q3q3;
        _4bx = 2.0f*_2bx; _4bz = 2.0f*_2bz;

        s0 = -_2q2*(2.0f*(q1q3 - q0q2) - ax) + _2q1*(2.0f*(q0q1 + q2q3) - ay)
           - _2bz*q2*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q3 + _2bz*q1)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q2*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s1 =  _2q3*(2.0f*(q1q3 - q0q2) - ax) + _2q0*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q1*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + _2bz*q3*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q2 + _2bz*q0)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q3 - _4bz*q1)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s2 = -_2q0*(2.0f*(q1q3 - q0q2) - ax) + _2q3*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q2*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + (-_4bx*q2 - _2bz*q0)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q1 + _2bz*q3)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q0 - _4bz*q2)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s3 =  _2q1*(2.0f*(q1q3 - q0q2) - ax) + _2q2*(2.0f*(q0q1 + q2q3) - ay)
           + (-_4bx*q3 + _2bz*q1)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q0 + _2bz*q2)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q1*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        recipNorm = 1.0f / sqrtf(s0*s0 + s1*s1 + s2*s2 + s3*s3);
        s0 *= recipNorm; s1 *= recipNorm; s2 *= recipNorm; s3 *= recipNorm;
        qDot1 -= BETA*s0; qDot2 -= BETA*s1; qDot3 -= BETA*s2; qDot4 -= BETA*s3;
    }

    q0 += qDot1*dt; q1 += qDot2*dt; q2 += qDot3*dt; q3 += qDot4*dt;
    recipNorm = 1.0f / sqrtf(q0*q0 + q1*q1 + q2*q2 + q3*q3);
    q0 *= recipNorm; q1 *= recipNorm; q2 *= recipNorm; q3 *= recipNorm;
}

/* 6-axis version (accel + gyro only) */
static void MadgwickUpdateIMU(float gx, float gy, float gz,
                              float ax, float ay, float az, float dt)
{
    float qDot1 = 0.5f * (-q1*gx - q2*gy - q3*gz);
    float qDot2 = 0.5f * ( q0*gx + q2*gz - q3*gy);
    float qDot3 = 0.5f * ( q0*gy - q1*gz + q3*gx);
    float qDot4 = 0.5f * ( q0*gz + q1*gy - q2*gx);
    float n = sqrtf(ax*ax + ay*ay + az*az);
    if (n > 0.3f) {
        ax /= n; ay /= n; az /= n;
        float s0 = 4*q0*q2*q2 + 2*q2*ax + 4*q0*q1*q1 - 2*q1*ay;
        float s1 = 4*q1*q3*q3 - 2*q3*ax + 4*q0*q0*q1 - 2*q0*ay - 4*q1 + 8*q1*q1*q1 + 8*q1*q2*q2 + 4*q1*az;
        float s2 = 4*q0*q0*q2 + 2*q0*ax + 4*q2*q3*q3 - 2*q3*ay - 4*q2 + 8*q2*q1*q1 + 8*q2*q2*q2 + 4*q2*az;
        float s3 = 4*q1*q1*q3 - 2*q1*ax + 4*q2*q2*q3 - 2*q2*ay;
        float sn = sqrtf(s0*s0 + s1*s1 + s2*s2 + s3*s3);
        if (sn > 0) { qDot1 -= BETA*s0/sn; qDot2 -= BETA*s1/sn; qDot3 -= BETA*s2/sn; qDot4 -= BETA*s3/sn; }
    }
    q0 += qDot1*dt; q1 += qDot2*dt; q2 += qDot3*dt; q3 += qDot4*dt;
    n = sqrtf(q0*q0 + q1*q1 + q2*q2 + q3*q3);
    q0 /= n; q1 /= n; q2 /= n; q3 /= n;
}

static void QuaternionToEuler(float *roll, float *pitch, float *yaw)
{
    float sinr_cosp = 2.0f * (q0*q1 + q2*q3);
    float cosr_cosp = 1.0f - 2.0f*(q1*q1 + q2*q2);
    *roll = atan2f(sinr_cosp, cosr_cosp) * 180.0f / (float)M_PI;

    float sinp = 2.0f * (q0*q2 - q3*q1);
    if (fabsf(sinp) >= 1.0f) *pitch = copysignf(90.0f, sinp);
    else                     *pitch = asinf(sinp) * 180.0f / (float)M_PI;

    float siny_cosp = 2.0f * (q0*q3 + q1*q2);
    float cosy_cosp = 1.0f - 2.0f*(q2*q2 + q3*q3);
    *yaw = atan2f(siny_cosp, cosy_cosp) * 180.0f / (float)M_PI;
}

/* USER CODE END 0 */

int main(void)
{
    /* USER CODE BEGIN 1 */
    /* USER CODE END 1 */

    HAL_Init();

    /* USER CODE BEGIN Init */
    /* USER CODE END Init */

    SystemClock_Config();

    /* USER CODE BEGIN SysInit */
    /* USER CODE END SysInit */

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART2_UART_Init();

    /* USER CODE BEGIN 2 */
    /* microsecond-accurate timer for the filter's dt */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;

    printf("\r\n# MK2 sensor fusion + viewer stream\r\n");
    MPU6050_Init();
    HMC5883L_Init();
    BMP180_Init();
    INA219_Init();

    /* sanity check: MPU WHO_AM_I */
    {
        uint8_t id = 0;
        I2C_ReadBurst(MPU6050_ADDR, 0x75, &id, 1);
        if (id == 0) printf("# ERROR: MPU-6050 not responding (check PB8/PB9, 3V3, GND)\r\n");
        else         printf("# MPU-6050 ok (WHO_AM_I=0x%02X)\r\n", id);
    }

    printf("# keep the board still: calibrating gyro...\r\n");
    {
        float ax, ay, az, gx, gy, gz, t, sx = 0, sy = 0, sz = 0;
        for (int i = 0; i < GYRO_CAL_SAMPLES; i++) {
            MPU6050_Read(&ax, &ay, &az, &gx, &gy, &gz, &t);
            sx += gx; sy += gy; sz += gz;
            HAL_Delay(4);
        }
        gbias_x = sx / GYRO_CAL_SAMPLES; gbias_y = sy / GYRO_CAL_SAMPLES; gbias_z = sz / GYRO_CAL_SAMPLES;
    }
    printf("# ready\r\n");

    float ax, ay, az, gx, gy, gz, imu_temp;
    float mx = 0, my = 0, mz = 0;
    float bmp_temp = 0, pressure = 0, altitude = 0;
    float bus_v = 0, current_mA = 0, power_mW = 0;
    float roll = 0, pitch = 0, yaw = 0;
    uint32_t viewer_timer = HAL_GetTick(), slow_timer = HAL_GetTick(), mag_timer = 0;
    last_cyc = DWT->CYCCNT;
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* ── fusion: as fast as the I2C read allows (~300-500 Hz) ── */
        MPU6050_Read(&ax, &ay, &az, &gx, &gy, &gz, &imu_temp);
        gx -= gbias_x; gy -= gbias_y; gz -= gbias_z;

        if (HAL_GetTick() - mag_timer >= 15) {          /* HMC5883L updates at 15 Hz */
            mag_timer = HAL_GetTick();
            HMC5883L_Read(&mx, &my, &mz);
        }

        uint32_t cyc = DWT->CYCCNT;
        float dt = (float)(cyc - last_cyc) / (float)SystemCoreClock;
        last_cyc = cyc;
        if (dt <= 0.0f || dt > 0.1f) dt = 0.005f;

#if USE_MAG
        if (mag_valid) MadgwickUpdate(gx, gy, gz, ax, ay, az, mx, my, mz, dt);
        else           MadgwickUpdateIMU(gx, gy, gz, ax, ay, az, dt);
#else
        MadgwickUpdateIMU(gx, gy, gz, ax, ay, az, dt);
#endif
        QuaternionToEuler(&roll, &pitch, &yaw);

        /* ── slow sensors: BMP180 + INA219 ── */
        if (HAL_GetTick() - slow_timer >= SLOW_PERIOD_MS) {
            slow_timer = HAL_GetTick();
            BMP180_Read(&bmp_temp, &pressure, &altitude);
            INA219_Read(&bus_v, &current_mA, &power_mW);
#if !DEBUG_PRINT
            char b[64], *p = b;
            p = put_str(p, "B,"); p = put_fixed(p, pressure / 100.0f, 2); *p++ = ','; p = put_fixed(p, bmp_temp, 1); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
            p = b; p = put_str(p, "V,"); p = put_fixed(p, bus_v, 2); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
#endif
        }

        /* ── stream to viewer ── */
        if (HAL_GetTick() - viewer_timer >= VIEWER_PERIOD_MS) {
            viewer_timer = HAL_GetTick();
#if DEBUG_PRINT
            printf("Roll %7.2f  Pitch %7.2f  Yaw %7.2f | P %.2f hPa  T %.1f C  V %.2f V\r\n",
                   roll, pitch, yaw, pressure / 100.0f, bmp_temp, bus_v);
#else
            char b[112], *p = b;
            p = put_str(p, "A,"); p = put_fixed(p, roll, 2); *p++ = ','; p = put_fixed(p, pitch, 2); *p++ = ','; p = put_fixed(p, yaw, 2); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));

            p = b; p = put_str(p, "R,");
            p = put_fixed(p, ax, 3); *p++ = ','; p = put_fixed(p, ay, 3); *p++ = ','; p = put_fixed(p, az, 3); *p++ = ',';
            p = put_fixed(p, gx * 57.29578f, 1); *p++ = ','; p = put_fixed(p, gy * 57.29578f, 1); *p++ = ','; p = put_fixed(p, gz * 57.29578f, 1); *p++ = ',';
            p = put_fixed(p, mx, 1); *p++ = ','; p = put_fixed(p, my, 1); *p++ = ','; p = put_fixed(p, mz, 1); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
#endif
        }
        /* USER CODE END WHILE */
    }
    /* USER CODE BEGIN 3 */
    /* USER CODE END 3 */
}

/* SYSTEM CLOCK (180 MHz via PLL on HSI) */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM       = 8;
    RCC_OscInitStruct.PLL.PLLN       = 180;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 4;
    RCC_OscInitStruct.PLL.PLLR       = 2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();
    if (HAL_PWREx_EnableOverDrive() != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) Error_Handler();
}

/* I2C1 (SCL=PB8, SDA=PB9, 100 kHz) */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance             = I2C1;
    hi2c1.Init.ClockSpeed      = 100000;
    hi2c1.Init.DutyCycle       = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1     = 0;
    hi2c1.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2     = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) Error_Handler();
    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK) Error_Handler();
    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK) Error_Handler();
}

/* USART2 (PA2=TX, PA3=RX, 115200 8N1) */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

void Error_Handler(void)
{
    __disable_irq();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_5; g.Mode = GPIO_MODE_OUTPUT_PP; g.Pull = GPIO_NOPULL; g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &g);
    while (1) { HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); for (volatile uint32_t i = 0; i < 4000000; i++) { } }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) { (void)file; (void)line; }
#endif
