/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Sensor Fusion — MPU6050 + HMC5883L + BMP180 + INA219
  *                   STM32F446RE Nucleo | Madgwick AHRS Filter
  *
  * ═══════════════════════════════════════════════════════════════
  *  CUBEMX SETUP — DO THIS FIRST BEFORE PASTING THIS CODE
  * ═══════════════════════════════════════════════════════════════
  *
  *  Step 1: New Project → Board Selector → NUCLEO-F446RE → OK
  *
  *  Step 2: Pinout & Configuration
  *    → Connectivity → I2C1
  *        Mode: I2C
  *        SCL pin: PB8  (auto-assigned)
  *        SDA pin: PB9  (auto-assigned)
  *        Speed: Standard Mode (100kHz)
  *
  *    → Connectivity → USART2
  *        Mode: Asynchronous
  *        Baud Rate: 115200
  *        Word Length: 8 Bits
  *        Parity: None
  *        Stop Bits: 1
  *        TX pin: PA2  (auto-assigned)
  *        RX pin: PA3  (auto-assigned)
  *
  *    → System Core → SYS
  *        Debug: Serial Wire
  *
  *  Step 3: Clock Configuration
  *    → Set HCLK to 180 MHz
  *      (Use HSE → PLL, or HSI → PLL. Click Resolve Clock Issues if prompted)
  *
  *  Step 4: Project Manager
  *    → Project Name: SensorFusion
  *    → Toolchain/IDE: STM32CubeIDE
  *    → Click Generate Code
  *
  *  Step 5: Open generated main.c and REPLACE its contents with this file.
  *          The generated main.c from CubeMX will have the same structure.
  *          This file keeps all /* USER CODE BEGIN/END * / markers intact
  *          so CubeMX regeneration won't overwrite your code.
  *
  *  Step 6: In Project → Properties → C/C++ Build → Settings
  *          → MCU GCC Compiler → Miscellaneous → add: -u _printf_float
  *          (enables float formatting in printf)
  *
  *  Step 7: Terminal: Open any serial monitor (e.g. STM32CubeIDE Console,
  *          PuTTY, or Termite) at 115200 baud on the Nucleo's COM port.
  *
  *  ─────────────────────────────────────────────────────────────
  *  WIRING (all sensors on the same I2C1 bus)
  *  ─────────────────────────────────────────────────────────────
  *  Sensor VCC  → 3.3V (Nucleo 3V3 pin)
  *  Sensor GND  → GND
  *  Sensor SDA  → PB9
  *  Sensor SCL  → PB8
  *  4.7kΩ pull-up on SDA and SCL to 3.3V (one set is enough for the bus)
  *
  *  I2C Addresses (7-bit):
  *    MPU-6050   0x68  (AD0 pin LOW)
  *    HMC5883L   0x1E
  *    BMP180     0x77
  *    INA219     0x40  (A0, A1 pins LOW)
  *
  *  INA219 NOTE: Configured for a 100Ω shunt resistor.
  *               Max measurable current = 3.2 mA (320mV / 100Ω).
  *               It reads bus voltage/current/power, not attitude — displayed
  *               separately from the fusion output.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    int16_t  AC1, AC2, AC3;
    uint16_t AC4, AC5, AC6;
    int16_t  B1, B2, MB, MC, MD;
} BMP180_Calib_t;

/* ── 1-D Kalman filter state for a single axis ── */
typedef struct {
    float x;   /* State estimate (filtered value)          */
    float P;   /* Estimate error covariance                */
    float Q;   /* Process noise  — how fast true field drifts  */
    float R;   /* Measurement noise — sensor noise variance     */
} KalmanAxis_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* ── I2C Device Addresses (7-bit << 1 for HAL) ── */
#define MPU6050_ADDR        (0x68 << 1)
#define HMC5883L_ADDR       (0x1E << 1)
#define BMP180_ADDR         (0x77 << 1)
#define INA219_ADDR         (0x40 << 1)

/* ── MPU-6050 Registers ── */
#define MPU_REG_SMPLRT_DIV  0x19
#define MPU_REG_CONFIG      0x1A
#define MPU_REG_GYRO_CFG    0x1B
#define MPU_REG_ACCEL_CFG   0x1C
#define MPU_REG_ACCEL_XOUT  0x3B
#define MPU_REG_TEMP_OUT    0x41
#define MPU_REG_GYRO_XOUT   0x43
#define MPU_REG_PWR_MGMT_1  0x6B

/* ── HMC5883L Registers ── */
#define HMC_REG_CFG_A       0x00
#define HMC_REG_CFG_B       0x01
#define HMC_REG_MODE        0x02
#define HMC_REG_DATA_XH     0x03

/* ── BMP180 Registers ── */
#define BMP_REG_CALIB       0xAA
#define BMP_REG_CTRL        0xF4
#define BMP_REG_DATA        0xF6
#define BMP_CMD_TEMP        0x2E
#define BMP_CMD_PRESS       0x34
#define BMP_OSS             0       /* Oversampling 0=single, 1,2,3=higher */

/* ── INA219 Registers ── */
#define INA_REG_CONFIG      0x00
#define INA_REG_SHUNT_V     0x01
#define INA_REG_BUS_V       0x02
#define INA_REG_POWER       0x03
#define INA_REG_CURRENT     0x04
#define INA_REG_CALIB       0x05

/* ── Madgwick Filter Parameters ── */
#define SAMPLE_FREQ         100.0f  /* Hz  — match your loop rate */
#define BETA                0.1f    /* Filter gain: higher = faster response
                                       but noisier. 0.033–0.15 is typical. */

/* ── Compass Kalman Filter Tuning ── */
/* Q: process noise — raise if the sensor moves quickly (e.g. drone)        */
/* R: measurement noise — raise if readings look jumpy, lower if too sluggish*/
#define MAG_KALMAN_Q        0.1f
#define MAG_KALMAN_R        5.0f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* Madgwick quaternion state */
static float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;

/* BMP180 factory calibration coefficients */
static BMP180_Calib_t bmp_cal;

/* Shared B5 term needed between temp and pressure calculation */
static int32_t bmp_B5;

/* Kalman filter state — one per magnetometer axis (X, Y, Z) */
static KalmanAxis_t mag_kx = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_ky = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_kz = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
/* ── I2C helpers ── */
static void     I2C_WriteReg  (uint8_t dev, uint8_t reg, uint8_t val);
static uint8_t  I2C_ReadReg   (uint8_t dev, uint8_t reg);
static void     I2C_ReadBurst (uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len);
static void     I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val);
static int16_t  I2C_ReadReg16 (uint8_t dev, uint8_t reg);

/* ── Sensor init ── */
static void MPU6050_Init  (void);
static void HMC5883L_Init (void);
static void BMP180_Init   (void);
static void INA219_Init   (void);

/* ── Sensor read ── */
static void MPU6050_Read  (float *ax, float *ay, float *az,
                            float *gx, float *gy, float *gz,
                            float *temp_c);
static void HMC5883L_Read (float *mx, float *my, float *mz);
static void BMP180_Read   (float *temp_c, float *press_pa, float *alt_m);
static void INA219_Read   (float *voltage, float *current_mA, float *power_mW);

/* ── Fusion ── */
static void MadgwickUpdate     (float gx, float gy, float gz,
                                 float ax, float ay, float az,
                                 float mx, float my, float mz);
static void QuaternionToEuler  (float *roll, float *pitch, float *yaw);

/* ── Kalman filter ── */
static float Kalman1D_Update   (KalmanAxis_t *k, float measurement);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ═══════════════════════════════════════════════════════════════
   PRINTF → UART REDIRECT
   ═══════════════════════════════════════════════════════════════ */
int __io_putchar(int ch)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

/* ═══════════════════════════════════════════════════════════════
   I2C HELPERS
   ═══════════════════════════════════════════════════════════════ */
static void I2C_WriteReg(uint8_t dev, uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 2, HAL_MAX_DELAY);
}

static uint8_t I2C_ReadReg(uint8_t dev, uint8_t reg)
{
    uint8_t val = 0;
    HAL_I2C_Master_Transmit(&hi2c1, dev, &reg, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Receive (&hi2c1, dev, &val, 1, HAL_MAX_DELAY);
    return val;
}

static void I2C_ReadBurst(uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len)
{
    HAL_I2C_Master_Transmit(&hi2c1, dev, &reg, 1,   HAL_MAX_DELAY);
    HAL_I2C_Master_Receive (&hi2c1, dev, buf,  len, HAL_MAX_DELAY);
}

static void I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = {reg, (uint8_t)(val >> 8), (uint8_t)(val & 0xFF)};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 3, HAL_MAX_DELAY);
}

static int16_t I2C_ReadReg16(uint8_t dev, uint8_t reg)
{
    uint8_t buf[2] = {0};
    HAL_I2C_Master_Transmit(&hi2c1, dev, &reg, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Receive (&hi2c1, dev, buf,  2, HAL_MAX_DELAY);
    return (int16_t)((buf[0] << 8) | buf[1]);
}

/* ═══════════════════════════════════════════════════════════════
   MPU-6050  (Accel ±2 g, Gyro ±500°/s)
   ═══════════════════════════════════════════════════════════════ */
static void MPU6050_Init(void)
{
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_PWR_MGMT_1, 0x00); /* Wake up            */
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_SMPLRT_DIV, 0x07); /* 1kHz/(1+7)=125Hz   */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_CONFIG,     0x06); /* DLPF ~5Hz bandwidth */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_GYRO_CFG,   0x08); /* FS_SEL=1 → ±500°/s */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_ACCEL_CFG,  0x00); /* AFS_SEL=0 → ±2g    */
}

static void MPU6050_Read(float *ax, float *ay, float *az,
                          float *gx, float *gy, float *gz,
                          float *temp_c)
{
    uint8_t buf[14];
    I2C_ReadBurst(MPU6050_ADDR, MPU_REG_ACCEL_XOUT, buf, 14);

    int16_t rax = (int16_t)((buf[0]  << 8) | buf[1]);
    int16_t ray = (int16_t)((buf[2]  << 8) | buf[3]);
    int16_t raz = (int16_t)((buf[4]  << 8) | buf[5]);
    int16_t rt  = (int16_t)((buf[6]  << 8) | buf[7]);
    int16_t rgx = (int16_t)((buf[8]  << 8) | buf[9]);
    int16_t rgy = (int16_t)((buf[10] << 8) | buf[11]);
    int16_t rgz = (int16_t)((buf[12] << 8) | buf[13]);

    /* ±2g  → 16384 LSB/g */
    *ax = rax / 16384.0f;
    *ay = ray / 16384.0f;
    *az = raz / 16384.0f;

    /* Temperature */
    *temp_c = (rt / 340.0f) + 36.53f;

    /* ±500°/s → 65.5 LSB/°/s → convert to rad/s for Madgwick */
    *gx = (rgx / 65.5f) * (float)M_PI / 180.0f;
    *gy = (rgy / 65.5f) * (float)M_PI / 180.0f;
    *gz = (rgz / 65.5f) * (float)M_PI / 180.0f;
}

/* ═══════════════════════════════════════════════════════════════
   HMC5883L  (Magnetometer, Gain 1.3 Ga → 1090 LSB/Gauss)
   ═══════════════════════════════════════════════════════════════ */
static void HMC5883L_Init(void)
{
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_A, 0x70); /* 8 avg, 15Hz, normal  */
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_B, 0x20); /* Gain: 1.3 Ga         */
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_MODE,  0x00); /* Continuous mode       */
}

static void HMC5883L_Read(float *mx, float *my, float *mz)
{
    uint8_t buf[6];
    I2C_ReadBurst(HMC5883L_ADDR, HMC_REG_DATA_XH, buf, 6);

    /* Register order: XH XL ZH ZL YH YL  (Z before Y — datasheet p.15) */
    int16_t rx = (int16_t)((buf[0] << 8) | buf[1]);
    int16_t rz = (int16_t)((buf[2] << 8) | buf[3]);
    int16_t ry = (int16_t)((buf[4] << 8) | buf[5]);

    /* Overflow detection: HMC5883L outputs -4096 on all axes when saturated.
       Skip the Kalman update entirely — hold the last valid estimate instead. */
    if (rx == -4096 || ry == -4096 || rz == -4096)
        return;  /* mag_k*.x already holds last valid filtered value */

    /* Convert to µT: 1090 LSB/Gauss × 100 µT/Gauss */
    float raw_x = rx / 1090.0f * 100.0f;
    float raw_y = ry / 1090.0f * 100.0f;
    float raw_z = rz / 1090.0f * 100.0f;

    /* Apply per-axis Kalman filter for noise reduction */
    *mx = Kalman1D_Update(&mag_kx, raw_x);
    *my = Kalman1D_Update(&mag_ky, raw_y);
    *mz = Kalman1D_Update(&mag_kz, raw_z);
}

/* ═══════════════════════════════════════════════════════════════
   1-D KALMAN FILTER
   Scalar predict-update cycle for a single sensor axis.
   Call once per new measurement; returns filtered estimate.

   Tuning:
     Q (process noise)   — increase if the signal changes rapidly
                           decrease if the true field is stable
     R (measurement noise) — increase to smooth more aggressively
                             decrease if the sensor is very accurate
   ═══════════════════════════════════════════════════════════════ */
static float Kalman1D_Update(KalmanAxis_t *k, float z)
{
    /* ── Predict ── */
    /* State propagates as identity (no dynamics model needed for a
       slowly varying magnetic field). Only covariance grows by Q. */
    float P_pred = k->P + k->Q;

    /* ── Update ── */
    float K      = P_pred / (P_pred + k->R);   /* Kalman gain           */
    k->x         = k->x + K * (z - k->x);      /* Corrected estimate    */
    k->P         = (1.0f - K) * P_pred;         /* Updated covariance    */

    return k->x;
}

/* ═══════════════════════════════════════════════════════════════
   BMP180  (Barometric pressure + temperature + altitude)
   ═══════════════════════════════════════════════════════════════ */
static void BMP180_Init(void)
{
    uint8_t buf[22];
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_CALIB, buf, 22);

    bmp_cal.AC1 = (int16_t) ((buf[0]  << 8) | buf[1]);
    bmp_cal.AC2 = (int16_t) ((buf[2]  << 8) | buf[3]);
    bmp_cal.AC3 = (int16_t) ((buf[4]  << 8) | buf[5]);
    bmp_cal.AC4 = (uint16_t)((buf[6]  << 8) | buf[7]);
    bmp_cal.AC5 = (uint16_t)((buf[8]  << 8) | buf[9]);
    bmp_cal.AC6 = (uint16_t)((buf[10] << 8) | buf[11]);
    bmp_cal.B1  = (int16_t) ((buf[12] << 8) | buf[13]);
    bmp_cal.B2  = (int16_t) ((buf[14] << 8) | buf[15]);
    bmp_cal.MB  = (int16_t) ((buf[16] << 8) | buf[17]);
    bmp_cal.MC  = (int16_t) ((buf[18] << 8) | buf[19]);
    bmp_cal.MD  = (int16_t) ((buf[20] << 8) | buf[21]);
}

static void BMP180_Read(float *temp_c, float *press_pa, float *alt_m)
{
    uint8_t buf[3];

    /* ── 1. Read raw temperature ─────────────────────────── */
    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_TEMP);
    HAL_Delay(5);
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 2);
    int32_t UT = (int32_t)((buf[0] << 8) | buf[1]);

    /* ── 2. Read raw pressure ────────────────────────────── */
    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_PRESS | (BMP_OSS << 6));
    HAL_Delay(26); /* OSS=0: 4.5ms min; 26ms gives margin for all OSS levels */
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 3);
    int32_t UP = (int32_t)(((buf[0] << 16) | (buf[1] << 8) | buf[2]) >> (8 - BMP_OSS));

    /* ── 3. Temperature (datasheet algorithm) ─────────────── */
    int32_t X1 = ((UT - (int32_t)bmp_cal.AC6) * (int32_t)bmp_cal.AC5) >> 15;
    int32_t X2 = ((int32_t)bmp_cal.MC << 11) / (X1 + (int32_t)bmp_cal.MD);
    bmp_B5 = X1 + X2;
    *temp_c = (float)((bmp_B5 + 8) >> 4) / 10.0f;

    /* ── 4. Pressure (datasheet algorithm) ───────────────── */
    int32_t B6 = bmp_B5 - 4000;
    X1 = ((int32_t)bmp_cal.B2 * ((B6 * B6) >> 12)) >> 11;
    X2 = ((int32_t)bmp_cal.AC2 * B6) >> 11;
    int32_t X3 = X1 + X2;
    int32_t B3 = (((((int32_t)bmp_cal.AC1 * 4) + X3) << BMP_OSS) + 2) >> 2;

    X1 = ((int32_t)bmp_cal.AC3 * B6) >> 13;
    X2 = ((int32_t)bmp_cal.B1 * ((B6 * B6) >> 12)) >> 16;
    X3 = ((X1 + X2) + 2) >> 2;
    uint32_t B4 = ((uint32_t)bmp_cal.AC4 * (uint32_t)(X3 + 32768)) >> 15;
    uint32_t B7 = ((uint32_t)UP - (uint32_t)B3) * (50000UL >> BMP_OSS);

    int32_t p;
    if (B7 < 0x80000000UL)
        p = (int32_t)((B7 << 1) / B4);
    else
        p = (int32_t)((B7 / B4) << 1);

    X1 = (p >> 8) * (p >> 8);
    X1 = (X1 * 3038) >> 16;
    X2 = (-7357 * p) >> 16;
    p  = p + ((X1 + X2 + 3791) >> 4);

    *press_pa = (float)p;

    /* ── 5. Altitude (International Barometric Formula) ──── */
    *alt_m = 44330.0f * (1.0f - powf(*press_pa / 101325.0f, 1.0f / 5.255f));
}

/* ═══════════════════════════════════════════════════════════════
   INA219  (Voltage / Current / Power monitor)
   100Ω shunt resistor, 32V bus range, max current ≈ 3.2 mA
   Current_LSB = 0.1 µA/bit  |  Power_LSB = 2 µW/bit
   ═══════════════════════════════════════════════════════════════ */
static void INA219_Init(void)
{
    /* Config: 32V bus, ±320mV shunt, 128-sample avg, continuous */
    I2C_WriteReg16(INA219_ADDR, INA_REG_CONFIG, 0x3FFF);

    /* Calibration for 100Ω shunt, max 3.2mA, Current_LSB = 0.1 µA/bit
       Cal = trunc(0.04096 / (0.1e-6 × 100)) = 4096 = 0x1000             */
    I2C_WriteReg16(INA219_ADDR, INA_REG_CALIB, 0x1000);
}

static void INA219_Read(float *voltage, float *current_mA, float *power_mW)
{
    int16_t raw_bus  = I2C_ReadReg16(INA219_ADDR, INA_REG_BUS_V);
    int16_t raw_cur  = I2C_ReadReg16(INA219_ADDR, INA_REG_CURRENT);
    int16_t raw_pwr  = I2C_ReadReg16(INA219_ADDR, INA_REG_POWER);

    /* Bus voltage: bits[15:3], LSB = 4 mV */
    *voltage    = (float)(raw_bus >> 3) * 0.004f;

    /* Current: LSB = 0.1 µA = 1e-7 A → convert to mA: × 1e-7 × 1000 = × 1e-4 */
    *current_mA = (float)raw_cur * 0.0001f;         /* result in mA */

    /* Power: LSB = 20 × 0.1 µA = 2 µW = 2e-6 W → convert to mW: × 2e-6 × 1000 = × 2e-3 */
    *power_mW   = (float)raw_pwr * 0.002f;           /* result in mW */
}

/* ═══════════════════════════════════════════════════════════════
   MADGWICK AHRS FILTER
   Reference: S. O. H. Madgwick, "An efficient orientation filter
   for inertial and inertial/magnetic sensor arrays", 2010.
   Input:  gx,gy,gz  — gyro  [rad/s]
           ax,ay,az  — accel [g, any unit — will be normalised]
           mx,my,mz  — mag   [any unit — will be normalised]
   Output: updates global q0..q3 quaternion
   ═══════════════════════════════════════════════════════════════ */
static void MadgwickUpdate(float gx, float gy, float gz,
                            float ax, float ay, float az,
                            float mx, float my, float mz)
{
    float recipNorm;
    float s0, s1, s2, s3;
    float qDot1, qDot2, qDot3, qDot4;
    float hx, hy;
    float _2q0mx, _2q0my, _2q0mz, _2q1mx;
    float _2bx, _2bz, _4bx, _4bz;
    float _2q0, _2q1, _2q2, _2q3;
    float q0q0, q0q1, q0q2, q0q3;
    float q1q1, q1q2, q1q3, q2q2, q2q3, q3q3;

    /* ── Rate of change of quaternion from gyroscope ── */
    qDot1 = 0.5f * (-q1*gx - q2*gy - q3*gz);
    qDot2 = 0.5f * ( q0*gx + q2*gz - q3*gy);
    qDot3 = 0.5f * ( q0*gy - q1*gz + q3*gx);
    qDot4 = 0.5f * ( q0*gz + q1*gy - q2*gx);

    /* ── Skip correction if accel or mag is zero ── */
    if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f)) &&
        !((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f)))
    {
        /* Normalise accelerometer */
        recipNorm = 1.0f / sqrtf(ax*ax + ay*ay + az*az);
        ax *= recipNorm; ay *= recipNorm; az *= recipNorm;

        /* Normalise magnetometer */
        recipNorm = 1.0f / sqrtf(mx*mx + my*my + mz*mz);
        mx *= recipNorm; my *= recipNorm; mz *= recipNorm;

        /* Precompute common products */
        _2q0mx = 2.0f * q0 * mx;
        _2q0my = 2.0f * q0 * my;
        _2q0mz = 2.0f * q0 * mz;
        _2q1mx = 2.0f * q1 * mx;
        _2q0   = 2.0f * q0;
        _2q1   = 2.0f * q1;
        _2q2   = 2.0f * q2;
        _2q3   = 2.0f * q3;
        q0q0 = q0*q0; q0q1 = q0*q1; q0q2 = q0*q2; q0q3 = q0*q3;
        q1q1 = q1*q1; q1q2 = q1*q2; q1q3 = q1*q3;
        q2q2 = q2*q2; q2q3 = q2*q3;
        q3q3 = q3*q3;

        /* Reference direction of Earth's magnetic field */
        hx = mx*q0q0 - _2q0my*q3 + _2q0mz*q2
           + mx*q1q1 + _2q1*my*q2 + _2q1*mz*q3
           - mx*q2q2 - mx*q3q3;
        hy = _2q0mx*q3 + my*q0q0 - _2q0mz*q1
           + _2q1mx*q2 - my*q1q1 + my*q2q2
           + _2q2*mz*q3 - my*q3q3;
        _2bx = sqrtf(hx*hx + hy*hy);
        _2bz = -_2q0mx*q2 + _2q0my*q1 + mz*q0q0
             +  _2q1mx*q3 - mz*q1q1 + _2q2*my*q3
             - mz*q2q2 + mz*q3q3;
        _4bx = 2.0f * _2bx;
        _4bz = 2.0f * _2bz;

        /* Gradient descent corrective step */
        s0 = -_2q2*(2.0f*(q1q3 - q0q2) - ax)
           +  _2q1*(2.0f*(q0q1 + q2q3) - ay)
           - _2bz*q2*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q3 + _2bz*q1)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q2*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        s1 =  _2q3*(2.0f*(q1q3 - q0q2) - ax)
           +  _2q0*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q1*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + _2bz*q3*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q2 + _2bz*q0)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q3 - _4bz*q1)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        s2 = -_2q0*(2.0f*(q1q3 - q0q2) - ax)
           +  _2q3*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q2*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + (-_4bx*q2 - _2bz*q0)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q1 + _2bz*q3)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q0 - _4bz*q2)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        s3 =  _2q1*(2.0f*(q1q3 - q0q2) - ax)
           +  _2q2*(2.0f*(q0q1 + q2q3) - ay)  /* note: correction term for s3 */
           + (-_4bx*q3 + _2bz*q1)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q0 + _2bz*q2)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q1*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        /* Normalise gradient step */
        recipNorm = 1.0f / sqrtf(s0*s0 + s1*s1 + s2*s2 + s3*s3);
        s0 *= recipNorm; s1 *= recipNorm;
        s2 *= recipNorm; s3 *= recipNorm;

        /* Apply feedback */
        qDot1 -= BETA * s0;
        qDot2 -= BETA * s1;
        qDot3 -= BETA * s2;
        qDot4 -= BETA * s3;
    }

    /* ── Integrate to get new quaternion ── */
    float dt = 1.0f / SAMPLE_FREQ;
    q0 += qDot1 * dt;
    q1 += qDot2 * dt;
    q2 += qDot3 * dt;
    q3 += qDot4 * dt;

    /* ── Normalise quaternion ── */
    recipNorm = 1.0f / sqrtf(q0*q0 + q1*q1 + q2*q2 + q3*q3);
    q0 *= recipNorm; q1 *= recipNorm;
    q2 *= recipNorm; q3 *= recipNorm;
}

/* ═══════════════════════════════════════════════════════════════
   QUATERNION → EULER ANGLES  (ZYX convention, degrees)
   Roll  = rotation about X
   Pitch = rotation about Y
   Yaw   = rotation about Z (heading, mag-corrected)
   ═══════════════════════════════════════════════════════════════ */
static void QuaternionToEuler(float *roll, float *pitch, float *yaw)
{
    /* Roll (φ) */
    float sinr_cosp = 2.0f * (q0*q1 + q2*q3);
    float cosr_cosp = 1.0f - 2.0f*(q1*q1 + q2*q2);
    *roll = atan2f(sinr_cosp, cosr_cosp) * 180.0f / (float)M_PI;

    /* Pitch (θ) — clamp to avoid gimbal at ±90° */
    float sinp = 2.0f * (q0*q2 - q3*q1);
    if (fabsf(sinp) >= 1.0f)
        *pitch = copysignf(90.0f, sinp);
    else
        *pitch = asinf(sinp) * 180.0f / (float)M_PI;

    /* Yaw (ψ) */
    float siny_cosp = 2.0f * (q0*q3 + q1*q2);
    float cosy_cosp = 1.0f - 2.0f*(q2*q2 + q3*q3);
    *yaw = atan2f(siny_cosp, cosy_cosp) * 180.0f / (float)M_PI;
}

/* USER CODE END 0 */

/* ═══════════════════════════════════════════════════════════════
   MAIN
   ═══════════════════════════════════════════════════════════════ */
int main(void)
{
    /* USER CODE BEGIN 1 */
    /* USER CODE END 1 */

    HAL_Init();

    /* USER CODE BEGIN Init */
    /* USER CODE END Init */

    SystemClock_Config();

    /* USER CODE BEGIN SysInit */
    /* USER CODE END SysInit */

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART2_UART_Init();

    /* USER CODE BEGIN 2 */
    printf("\r\n");
    printf("================================================\r\n");
    printf("  STM32F446RE Sensor Fusion System\r\n");
    printf("  MPU6050 | HMC5883L | BMP180 | INA219\r\n");
    printf("  Madgwick AHRS @ %.0f Hz\r\n", SAMPLE_FREQ);
    printf("================================================\r\n\r\n");

    printf("Initialising sensors...\r\n");

    MPU6050_Init();
    printf("  [OK] MPU-6050  (Accel + Gyro)\r\n");

    HMC5883L_Init();
    printf("  [OK] HMC5883L  (Magnetometer)\r\n");

    BMP180_Init();
    printf("  [OK] BMP180    (Baro + Temp)\r\n");

    INA219_Init();
    printf("  [OK] INA219    (Voltage / Current)\r\n\r\n");

    printf("All sensors ready. Starting loop...\r\n\r\n");
    HAL_Delay(500);

    /* Working variables */
    float ax, ay, az, gx, gy, gz, imu_temp;
    float mx, my, mz;
    float bmp_temp, pressure, altitude;
    float bus_v, current_mA, power_mW;
    float roll, pitch, yaw;

    uint32_t fusion_timer = 0;   /* 100Hz Madgwick update     */
    uint32_t print_timer  = 0;   /* 10Hz  terminal print      */
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* ── 100 Hz: Read IMU + Mag + run Madgwick ── */
        if (HAL_GetTick() - fusion_timer >= 10)
        {
            fusion_timer = HAL_GetTick();
            MPU6050_Read (&ax, &ay, &az, &gx, &gy, &gz, &imu_temp);
            HMC5883L_Read(&mx, &my, &mz);
            MadgwickUpdate(gx, gy, gz, ax, ay, az, mx, my, mz);
            QuaternionToEuler(&roll, &pitch, &yaw);
        }

        /* ── 10 Hz: Read slow sensors + print all ── */
        /* NOTE: BMP180_Read blocks for ~31ms (5ms temp + 26ms pressure).
           This is safe at 10Hz (100ms window) but will cause the fusion
           loop above to miss ~3 ticks during the read. If you need tighter
           timing, move BMP180 to a state machine with non-blocking delays. */
        if (HAL_GetTick() - print_timer >= 100)
        {
            print_timer = HAL_GetTick();

            BMP180_Read(&bmp_temp, &pressure, &altitude);
            INA219_Read(&bus_v, &current_mA, &power_mW);

            printf("──────────────────────────────────────\r\n");

            /* IMU */
            printf("[MPU6050] Accel   : X=%6.3fg   Y=%6.3fg   Z=%6.3fg\r\n",
                   ax, ay, az);
            printf("[MPU6050] Gyro    : X=%7.2f   Y=%7.2f   Z=%7.2f  deg/s\r\n",
                   gx * 180.0f / (float)M_PI,
                   gy * 180.0f / (float)M_PI,
                   gz * 180.0f / (float)M_PI);
            printf("[MPU6050] Temp    : %.2f C\r\n", imu_temp);

            /* Magnetometer */
            printf("[HMC5883L] Mag    : X=%7.2f   Y=%7.2f   Z=%7.2f  uT\r\n",
                   mx, my, mz);

            /* Barometer */
            printf("[BMP180]  Temp    : %.2f C\r\n", bmp_temp);
            printf("[BMP180]  Pressure: %.2f hPa\r\n", pressure / 100.0f);
            printf("[BMP180]  Altitude: %.2f m\r\n", altitude);

            /* Power */
            printf("[INA219]  Voltage : %.3f V\r\n",  bus_v);
            printf("[INA219]  Current : %.4f mA\r\n", current_mA);
            printf("[INA219]  Power   : %.4f mW\r\n", power_mW);

            /* Fusion output */
            printf("[FUSION]  Roll    : %8.2f deg\r\n", roll);
            printf("[FUSION]  Pitch   : %8.2f deg\r\n", pitch);
            printf("[FUSION]  Yaw     : %8.2f deg\r\n", yaw);
            printf("[FUSION]  Quat    : w=%7.4f  x=%7.4f  y=%7.4f  z=%7.4f\r\n",
                   q0, q1, q2, q3);
            printf("\r\n");
        }
        /* USER CODE END WHILE */
    }
    /* USER CODE BEGIN 3 */
    /* USER CODE END 3 */
}

/* ═══════════════════════════════════════════════════════════════
   SYSTEM CLOCK  (180 MHz via PLL on HSI 16 MHz)
   If CubeMX generated a different SystemClock_Config, keep that
   one instead — this is a safe fallback for 180 MHz.
   ═══════════════════════════════════════════════════════════════ */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM       = 8;
    RCC_OscInitStruct.PLL.PLLN       = 180;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 4;
    RCC_OscInitStruct.PLL.PLLR       = 2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
        Error_Handler();

    if (HAL_PWREx_EnableOverDrive() != HAL_OK)
        Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
        Error_Handler();
}

/* ═══════════════════════════════════════════════════════════════
   I2C1 INIT  (SCL=PB8, SDA=PB9, Standard Mode 100kHz)
   ═══════════════════════════════════════════════════════════════ */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance             = I2C1;
    hi2c1.Init.ClockSpeed      = 100000;
    hi2c1.Init.DutyCycle       = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1     = 0;
    hi2c1.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2     = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
        Error_Handler();
    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
        Error_Handler();
    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
        Error_Handler();
}

/* ═══════════════════════════════════════════════════════════════
   USART2 INIT  (PA2=TX, PA3=RX, 115200 8N1)
   ═══════════════════════════════════════════════════════════════ */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK)
        Error_Handler();
}

/* ═══════════════════════════════════════════════════════════════
   GPIO INIT
   ═══════════════════════════════════════════════════════════════ */
static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/* ═══════════════════════════════════════════════════════════════
   ERROR HANDLER
   ═══════════════════════════════════════════════════════════════ */
void Error_Handler(void)
{
    __disable_irq();
    /* Blink onboard LED (PA5) to signal fault */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin  = GPIO_PIN_5;
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &g);
    while (1)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        HAL_Delay(200);
    }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    /* printf("assert failed: file %s, line %lu\r\n", file, line); */
}
#endif /* USE_FULL_ASSERT */
