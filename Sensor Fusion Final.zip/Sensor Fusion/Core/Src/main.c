/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : MK2 Sensor Fusion + Live Viewer Stream
  *                   MPU6050 + HMC5883L/QMC5883L + BMP180/BMP280 + INA219
 *
 *  OCT 29 UPDATE (breadboard #2)
 *    At start-up it now scans I2C and picks the magnetometer (QMC5883L at 0x0D
 *    or HMC5883L at 0x1E) and barometer (BMP280 at 0x76/0x77 or BMP180 at 0x77)
 *    that are actually there, and prints what it found as '#' lines. The new
 *    code is in the BREADBOARD #2 SUPPORT block at the end of USER CODE 0.
 *
 *  NOV 3 UPDATE (flight control bench build)  -- NO ESCs, NO PROPELLERS --
 *    Fixed 400 Hz loop, SBUS input on PA10 (D2) through the 74LS04 inverter,
 *    cascaded PID (angle 100 Hz -> rate 400 Hz), X mixer, arming/failsafe,
 *    PWM on PC6-PC9 (TIM3 CH1-CH4 = FL, FR, RR, RL), loop-timing pin PB5 (D4),
 *    I2C at 400 kHz, MPU-6050 at 500 Hz, and non-blocking serial output.
 *    Extra lines for MK2_PID_Viewer.html: S (sticks), C (control), K (PID
 *    terms), T (loop timing). Settings: FLIGHT CONTROL SETTINGS below.
 *    Gains are starting values and are NOT tuned.
  *                   STM32F446RE Nucleo | Madgwick AHRS Filter
  *
  *  WHAT THIS DOES
  *    Reads all four sensors, runs the Madgwick filter, and streams the result
  *    over USART2 (ST-Link virtual COM port, 115200 8N1) in the line format used
  *    by MK2_Attitude_Viewer.html:
  *        A,roll,pitch,yaw          (deg)            30 times/second
  *        R,ax,ay,az,gx,gy,gz,mx,my,mz  (g, deg/s, uT)  30 times/second
  *        B,pressure_hPa,temp_C     (BMP180/BMP280)   2 times/second
  *        V,bus_voltage_V           (INA219)          2 times/second
  *    Lines starting with '#' are comments the viewer ignores.
  *
  *  SETUP (same as your working Sensor Fusion project)
  *    I2C1: SCL=PB8, SDA=PB9, 100 kHz     USART2: PA2/PA3, 115200 8N1
  *    Paste this whole file over Core/Src/main.c.  No printf-float setting needed.
  *
  *  SWITCHES (see USER SETTINGS below)
  *    USE_MAG        1 = use magnetometer for yaw, 0 = gyro-only yaw (drifts)
  *    DEBUG_PRINT    1 = old human-readable printout instead of viewer stream
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct {
    int16_t  AC1, AC2, AC3;
    uint16_t AC4, AC5, AC6;
    int16_t  B1, B2, MB, MC, MD;
} BMP180_Calib_t;

typedef struct {
    float x;   /* State estimate (filtered value)          */
    float P;   /* Estimate error covariance                */
    float Q;   /* Process noise                            */
    float R;   /* Measurement noise                        */
} KalmanAxis_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* ───────────────────────── USER SETTINGS ───────────────────────── */
#define USE_MAG             1       /* 1 = magnetometer fused (heading), 0 = IMU only   */
#define DEBUG_PRINT         0       /* 1 = readable text instead of viewer stream       */
#define VIEWER_PERIOD_MS    33      /* A + R lines  (~30 Hz)                            */
#define SLOW_PERIOD_MS      500     /* BMP180 + INA219 lines (2 Hz)                     */
#define GYRO_CAL_SAMPLES    300     /* keep board still for ~1 s at power-up            */

/* If yaw/roll looks twisted when USE_MAG=1, the magnetometer module is mounted with
   different axes than the MPU-6050. Change these three expressions (x,y,z = raw mag)
   e.g.  (y), (-x), (z)   until the compass rotates the right way.                    */
#define MAG_FX(x,y,z)       (x)
#define MAG_FY(x,y,z)       (y)
#define MAG_FZ(x,y,z)       (z)
/* ───────────────────────────────────────────────────────────────── */

/* ─────────────── FLIGHT CONTROL SETTINGS (bench build, Nov 3 2026) ───────────────
   BENCH ONLY: no ESCs, no propellers. The gains below are STARTING VALUES, NOT TUNED.

   Body axes, as the filter reports them with the MPU-6050 Z axis pointing up:
     front of the board = the MPU-6050's +X arrow
     roll  +  = right side down
     pitch +  = nose down
     yaw   +  = counterclockwise seen from above                                   */
#define STREAM_CONTROL      1       /* 1 = send S/C/K/T lines for MK2_PID_Viewer.html.
                                       Set to 0 when using the old attitude viewer     */
#define I2C_SPEED_HZ        400000  /* starting speed; the firmware drops to 100000 by
                                       itself if the bus keeps failing                 */
#define LOOP_HZ             400     /* inner (rate) loop                               */
#define OUTER_DIV           4       /* outer (angle) loop every 4th pass = 100 Hz      */
#define PWM_HZ              50      /* ESC pulse rate. 50 Hz works with every ESC;
                                       raise to 400 only if your ESCs support it       */
#define MOTOR_OFF_US        1000    /* disarmed                                        */
#define MOTOR_IDLE_US       1080    /* armed, throttle at the bottom                   */
#define MOTOR_MAX_US        1500    /* BENCH LIMIT with real motors. Flight value: 2000 */
#define THR_ACTIVE_US       1100    /* below this the PID output is not used and the
                                       integral is held at zero (no windup)            */
#define THR_ARM_MAX_US      1050    /* throttle must be below this to arm              */

/* SBUS channel map (0 = CH1). RadioLink's default order is CH1 roll (aileron),
   CH2 pitch (elevator), CH3 throttle, CH4 yaw (rudder). The viewer's channel bars
   show which channel each stick and switch moves.                                 */
#define CH_ROLL             0
#define CH_PITCH            1
#define CH_THR              2
#define CH_YAW              3
#define CH_ARM              6       /* CH7: the 2-position switch; high = arm          */
#define REV_ROLL            0       /* set to 1 if that stick works backwards         */
#define REV_PITCH           0
#define REV_YAW             0
#define SBUS_MIN            172     /* raw value at one end of stick travel. Move the */
#define SBUS_MID            992     /* sticks to the ends, read the min/max in the    */
#define SBUS_MAX            1811    /* viewer, and type your numbers in here          */
#define SBUS_TIMEOUT_MS     200     /* disarm if no SBUS frame arrives for this long  */

#define MAX_ANGLE_DEG       30.0f   /* full roll/pitch stick = 30 deg                 */
#define MAX_YAW_RATE_DPS    180.0f  /* full yaw stick = 180 deg/s                     */
#define TILT_CUTOFF_DEG     70.0f   /* disarm if the board tips past this             */

/* PID gains. Outer loop: deg/s of rate command per deg of angle error.
   Inner loops: microseconds of motor pulse per deg/s (P), per deg (I),
   and per deg/s^2 (D).                                                            */
#define ANGLE_KP            4.0f
#define RATE_RP_KP          0.70f
#define RATE_RP_KI          0.40f
#define RATE_RP_KD          0.015f
#define RATE_Y_KP           1.50f
#define RATE_Y_KI           0.50f
#define RATE_Y_KD           0.0f
#define RATE_SP_MAX_DPS     200.0f  /* limit on the outer loop's rate command         */
#define UOUT_MAX_RP_US      200.0f  /* limit on the roll and pitch effort             */
#define UOUT_MAX_Y_US       150.0f  /* limit on the yaw effort                        */
#define I_MAX_US            100.0f  /* integral clamp                                 */
#define D_LPF_HZ            30.0f   /* low-pass filter on the D term                  */
#define YAW_SIGN            1       /* +1 if the front-right and rear-left propellers
                                       spin clockwise seen from above, -1 if they spin
                                       counterclockwise                                */
/* ───────────────────────────────────────────────────────────────── */

/* ── I2C Device Addresses (7-bit << 1 for HAL) ── */
static uint8_t mpu_addr = (0x68 << 1);  /* switches to 0x69 by itself if the sensor answers there (AD0 high) */
#define MPU6050_ADDR        mpu_addr
#define HMC5883L_ADDR       (0x1E << 1)
#define BMP180_ADDR         (0x77 << 1)
#define INA219_ADDR         (0x40 << 1)
#define I2C_TO              20      /* ms timeout, so a missing sensor cannot hang the loop */

/* ── MPU-6050 Registers ── */
#define MPU_REG_SMPLRT_DIV  0x19
#define MPU_REG_CONFIG      0x1A
#define MPU_REG_GYRO_CFG    0x1B
#define MPU_REG_ACCEL_CFG   0x1C
#define MPU_REG_ACCEL_XOUT  0x3B
#define MPU_REG_PWR_MGMT_1  0x6B

/* ── HMC5883L Registers ── */
#define HMC_REG_CFG_A       0x00
#define HMC_REG_CFG_B       0x01
#define HMC_REG_MODE        0x02
#define HMC_REG_DATA_XH     0x03

/* ── BMP180 Registers ── */
#define BMP_REG_CALIB       0xAA
#define BMP_REG_CTRL        0xF4
#define BMP_REG_DATA        0xF6
#define BMP_CMD_TEMP        0x2E
#define BMP_CMD_PRESS       0x34
#define BMP_OSS             0

/* ── INA219 Registers ── */
#define INA_REG_CONFIG      0x00
#define INA_REG_BUS_V       0x02
#define INA_REG_POWER       0x03
#define INA_REG_CURRENT     0x04
#define INA_REG_CALIB       0x05

/* ── Madgwick / Kalman ── */
#define BETA                0.1f    /* higher = trusts accel/mag more, noisier */
#define MAG_KALMAN_Q        0.1f
#define MAG_KALMAN_R        5.0f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;   /* Madgwick quaternion */
static BMP180_Calib_t bmp_cal;
static int32_t bmp_B5;
static KalmanAxis_t mag_kx = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_ky = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static KalmanAxis_t mag_kz = {0.0f, 1.0f, MAG_KALMAN_Q, MAG_KALMAN_R};
static float gbias_x = 0, gbias_y = 0, gbias_z = 0;         /* gyro bias, rad/s    */
static uint8_t mag_valid = 0;                               /* got a good mag read */
static float last_mx = 0, last_my = 0, last_mz = 0;         /* last good mag, uT   */
static uint32_t last_cyc = 0;                               /* DWT timestamp       */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
static void     I2C_WriteReg  (uint8_t dev, uint8_t reg, uint8_t val);
static uint8_t  I2C_ReadBurst (uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len);
static void     I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val);
static int16_t  I2C_ReadReg16 (uint8_t dev, uint8_t reg);

static void MPU6050_Init  (void);
static void HMC5883L_Init (void);
static void BMP180_Init   (void);
static void INA219_Init   (void);

static uint8_t MPU6050_Read  (float *ax, float *ay, float *az,
                            float *gx, float *gy, float *gz, float *temp_c);
static void HMC5883L_Read (float *mx, float *my, float *mz);
static void BMP180_Read   (float *temp_c, float *press_pa, float *alt_m);
static void INA219_Read   (float *voltage, float *current_mA, float *power_mW);

static void MadgwickUpdate    (float gx, float gy, float gz, float ax, float ay, float az,
                               float mx, float my, float mz, float dt);
static void MadgwickUpdateIMU (float gx, float gy, float gz, float ax, float ay, float az, float dt);
static void QuaternionToEuler (float *roll, float *pitch, float *yaw);
static float Kalman1D_Update  (KalmanAxis_t *k, float measurement);

static void uart_send   (const char *s, uint16_t n);
static char *put_str    (char *p, const char *s);
static char *put_fixed  (char *p, float v, int dec);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ── non-blocking serial output ──
   Lines go into a ring buffer and the USART2 TX interrupt sends them in the
   background, so printing no longer stalls the control loop. If the buffer is
   full, the whole line is dropped (counted in tx_drops) instead of waiting.     */
#define TX_BUF_SIZE 2048u                    /* must be a power of 2 */
static volatile uint8_t  tx_buf[TX_BUF_SIZE];
static volatile uint16_t tx_head = 0, tx_tail = 0;
static volatile uint8_t  tx_irq_on = 0;
static volatile uint32_t tx_drops = 0;

static uint16_t tx_free(void)
{
    return (uint16_t)((tx_tail - tx_head - 1u) & (TX_BUF_SIZE - 1u));
}

static void UART_TxInit(void)                /* call once, right after MX_USART2_UART_Init() */
{
    HAL_NVIC_SetPriority(USART2_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
    tx_irq_on = 1;
}

static void uart_send(const char *s, uint16_t n)
{
    if (!tx_irq_on) { HAL_UART_Transmit(&huart2, (uint8_t *)s, n, 50); return; }
    if (n > tx_free()) { tx_drops++; return; }
    uint16_t h = tx_head;
    for (uint16_t i = 0; i < n; i++) { tx_buf[h] = (uint8_t)s[i]; h = (uint16_t)((h + 1u) & (TX_BUF_SIZE - 1u)); }
    tx_head = h;
    __disable_irq();
    USART2->CR1 |= USART_CR1_TXEIE;          /* start (or keep) the TX interrupt */
    __enable_irq();
}

void USART2_IRQHandler(void)
{
    if ((USART2->SR & USART_SR_TXE) && (USART2->CR1 & USART_CR1_TXEIE)) {
        if (tx_tail != tx_head) {
            USART2->DR = tx_buf[tx_tail];
            tx_tail = (uint16_t)((tx_tail + 1u) & (TX_BUF_SIZE - 1u));
        } else {
            USART2->CR1 &= ~USART_CR1_TXEIE; /* nothing left to send */
        }
    }
}

/* printf -> UART (start-up messages and DEBUG_PRINT). Waits for room instead of dropping. */
int __io_putchar(int ch)
{
    char c = (char)ch;
    if (tx_irq_on) { while (tx_free() == 0) { } uart_send(&c, 1); }
    else HAL_UART_Transmit(&huart2, (uint8_t *)&c, 1, HAL_MAX_DELAY);
    return ch;
}

/* ── tiny integer-only number formatting (no printf-float setting needed) ── */
static char *put_str(char *p, const char *s) { while (*s) *p++ = *s++; return p; }

static char *put_fixed(char *p, float v, int dec)
{
    if (v != v) v = 0.0f;                       /* NaN guard */
    if (v < 0)  { v = -v; *p++ = '-'; }
    if (v > 2000000.0f) v = 2000000.0f;
    uint32_t scale = 1; for (int i = 0; i < dec; i++) scale *= 10;
    uint32_t n = (uint32_t)(v * (float)scale + 0.5f);
    uint32_t whole = n / scale, frac = n % scale;
    char t[12]; int k = 0;
    do { t[k++] = (char)('0' + whole % 10); whole /= 10; } while (whole);
    while (k) *p++ = t[--k];
    if (dec) {
        *p++ = '.';
        uint32_t div = scale / 10;
        for (int i = 0; i < dec; i++) { *p++ = (char)('0' + (frac / div) % 10); div /= 10; if (!div) div = 1; }
    }
    return p;
}


/* ═════════════ I2C HELPERS (with timeouts) ═════════════ */
static void I2C_WriteReg(uint8_t dev, uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = {reg, val};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 2, I2C_TO);
}

/* Returns 1 when the read worked. On a failure the buffer is zeroed and 0 is returned. */
static uint8_t I2C_ReadBurst(uint8_t dev, uint8_t reg, uint8_t *buf, uint16_t len)
{
    if (HAL_I2C_Master_Transmit(&hi2c1, dev, &reg, 1, I2C_TO) != HAL_OK) { memset(buf, 0, len); return 0; }
    if (HAL_I2C_Master_Receive (&hi2c1, dev, buf, len, I2C_TO) != HAL_OK) { memset(buf, 0, len); return 0; }
    return 1;
}

/* ───────────── I2C bus recovery ─────────────
   If a sensor is left holding SDA low (a glitch on a breadboard wire is enough), the
   STM32 sees the bus as busy for ever and every read times out. This frees the bus:
   clock SCL nine times by hand so the sensor lets go, send a STOP, reset the I2C
   peripheral, and start it again at the speed in i2c_speed_hz.                       */
static uint32_t i2c_speed_hz = I2C_SPEED_HZ;
static uint8_t  i2c_sda_idle = 1, i2c_scl_idle = 1;   /* line levels seen with the bus released */
static void I2C_DelayUs(uint32_t us)
{
    uint32_t t0 = DWT->CYCCNT, n = us * (SystemCoreClock / 1000000U);
    while ((DWT->CYCCNT - t0) < n) { }
}
static void I2C_BusRecover(void)
{
    GPIO_InitTypeDef g = {0};
    HAL_I2C_DeInit(&hi2c1);
    __HAL_RCC_GPIOB_CLK_ENABLE();
    g.Pin = GPIO_PIN_8 | GPIO_PIN_9; g.Mode = GPIO_MODE_OUTPUT_OD; g.Pull = GPIO_PULLUP; g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &g);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8 | GPIO_PIN_9, GPIO_PIN_SET);    /* release both lines */
    I2C_DelayUs(200);
    i2c_scl_idle = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_SET);   /* a healthy idle bus reads high on both */
    i2c_sda_idle = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_SET);
    for (int i = 0; i < 9; i++) {                                       /* 9 clocks on SCL (PB8) */
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET); I2C_DelayUs(10);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);   I2C_DelayUs(10);
    }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); I2C_DelayUs(10);   /* STOP: SDA rises while SCL is high */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);   I2C_DelayUs(10);
    __HAL_RCC_I2C1_FORCE_RESET(); __HAL_RCC_I2C1_RELEASE_RESET();
    MX_I2C1_Init();                                                     /* pins go back to I2C here */
}

static void I2C_WriteReg16(uint8_t dev, uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = {reg, (uint8_t)(val >> 8), (uint8_t)(val & 0xFF)};
    HAL_I2C_Master_Transmit(&hi2c1, dev, buf, 3, I2C_TO);
}

static int16_t I2C_ReadReg16(uint8_t dev, uint8_t reg)
{
    uint8_t buf[2] = {0};
    I2C_ReadBurst(dev, reg, buf, 2);
    return (int16_t)((buf[0] << 8) | buf[1]);
}

/* ═════════════ MPU-6050 (Accel ±2 g, Gyro ±500 deg/s) ═════════════ */
static void MPU6050_Init(void)
{
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_PWR_MGMT_1, 0x00);
    HAL_Delay(100);
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_SMPLRT_DIV, 0x01);   /* 500 Hz (was 125 Hz)        */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_CONFIG,     0x03);   /* DLPF ~44 Hz (was 5 Hz: too laggy for live animation) */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_GYRO_CFG,   0x08);   /* +-500 deg/s                */
    I2C_WriteReg(MPU6050_ADDR, MPU_REG_ACCEL_CFG,  0x00);   /* +-2 g                      */
}

/* Returns 1 for a good sample. On a failed read it returns 0 and leaves the outputs
   alone, so the caller keeps the last good values instead of a row of zeros.          */
static uint8_t MPU6050_Read(float *ax, float *ay, float *az,
                            float *gx, float *gy, float *gz, float *temp_c)
{
    uint8_t buf[14];
    if (!I2C_ReadBurst(MPU6050_ADDR, MPU_REG_ACCEL_XOUT, buf, 14)) return 0;

    int16_t rax = (int16_t)((buf[0]  << 8) | buf[1]);
    int16_t ray = (int16_t)((buf[2]  << 8) | buf[3]);
    int16_t raz = (int16_t)((buf[4]  << 8) | buf[5]);
    int16_t rt  = (int16_t)((buf[6]  << 8) | buf[7]);
    int16_t rgx = (int16_t)((buf[8]  << 8) | buf[9]);
    int16_t rgy = (int16_t)((buf[10] << 8) | buf[11]);
    int16_t rgz = (int16_t)((buf[12] << 8) | buf[13]);

    *ax = rax / 16384.0f;  *ay = ray / 16384.0f;  *az = raz / 16384.0f;
    *temp_c = (rt / 340.0f) + 36.53f;
    *gx = (rgx / 65.5f) * (float)M_PI / 180.0f;     /* rad/s */
    *gy = (rgy / 65.5f) * (float)M_PI / 180.0f;
    *gz = (rgz / 65.5f) * (float)M_PI / 180.0f;
    return 1;
}

/* ═════════════ HMC5883L (1.3 Ga, 1090 LSB/Gauss) ═════════════ */
static void HMC5883L_Init(void)
{
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_A, 0x70);   /* 8 avg, 15 Hz */
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_CFG_B, 0x20);
    I2C_WriteReg(HMC5883L_ADDR, HMC_REG_MODE,  0x00);   /* continuous   */
}

static void HMC5883L_Read(float *mx, float *my, float *mz)
{
    uint8_t buf[6];
    I2C_ReadBurst(HMC5883L_ADDR, HMC_REG_DATA_XH, buf, 6);

    /* register order: XH XL ZH ZL YH YL */
    int16_t rx = (int16_t)((buf[0] << 8) | buf[1]);
    int16_t rz = (int16_t)((buf[2] << 8) | buf[3]);
    int16_t ry = (int16_t)((buf[4] << 8) | buf[5]);

    /* all zero = failed read, -4096 = saturated: keep last good value */
    if ((rx == 0 && ry == 0 && rz == 0) || rx == -4096 || ry == -4096 || rz == -4096) {
        *mx = last_mx; *my = last_my; *mz = last_mz;
        return;
    }
    float x = rx / 1090.0f * 100.0f;      /* -> uT */
    float y = ry / 1090.0f * 100.0f;
    float z = rz / 1090.0f * 100.0f;

    float fx = MAG_FX(x, y, z), fy = MAG_FY(x, y, z), fz = MAG_FZ(x, y, z);
    last_mx = *mx = Kalman1D_Update(&mag_kx, fx);
    last_my = *my = Kalman1D_Update(&mag_ky, fy);
    last_mz = *mz = Kalman1D_Update(&mag_kz, fz);
    mag_valid = 1;
}

static float Kalman1D_Update(KalmanAxis_t *k, float z)
{
    float P_pred = k->P + k->Q;
    float K = P_pred / (P_pred + k->R);
    k->x = k->x + K * (z - k->x);
    k->P = (1.0f - K) * P_pred;
    return k->x;
}

/* ═════════════ BMP180 ═════════════ */
static void BMP180_Init(void)
{
    uint8_t buf[22];
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_CALIB, buf, 22);
    bmp_cal.AC1 = (int16_t) ((buf[0]  << 8) | buf[1]);
    bmp_cal.AC2 = (int16_t) ((buf[2]  << 8) | buf[3]);
    bmp_cal.AC3 = (int16_t) ((buf[4]  << 8) | buf[5]);
    bmp_cal.AC4 = (uint16_t)((buf[6]  << 8) | buf[7]);
    bmp_cal.AC5 = (uint16_t)((buf[8]  << 8) | buf[9]);
    bmp_cal.AC6 = (uint16_t)((buf[10] << 8) | buf[11]);
    bmp_cal.B1  = (int16_t) ((buf[12] << 8) | buf[13]);
    bmp_cal.B2  = (int16_t) ((buf[14] << 8) | buf[15]);
    bmp_cal.MB  = (int16_t) ((buf[16] << 8) | buf[17]);
    bmp_cal.MC  = (int16_t) ((buf[18] << 8) | buf[19]);
    bmp_cal.MD  = (int16_t) ((buf[20] << 8) | buf[21]);
}

static void BMP180_Read(float *temp_c, float *press_pa, float *alt_m)
{
    uint8_t buf[3];

    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_TEMP);
    HAL_Delay(5);
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 2);
    int32_t UT = (int32_t)((buf[0] << 8) | buf[1]);

    I2C_WriteReg(BMP180_ADDR, BMP_REG_CTRL, BMP_CMD_PRESS | (BMP_OSS << 6));
    HAL_Delay(8);                                   /* OSS=0 needs 4.5 ms */
    I2C_ReadBurst(BMP180_ADDR, BMP_REG_DATA, buf, 3);
    int32_t UP = (int32_t)(((buf[0] << 16) | (buf[1] << 8) | buf[2]) >> (8 - BMP_OSS));

    int32_t X1 = ((UT - (int32_t)bmp_cal.AC6) * (int32_t)bmp_cal.AC5) >> 15;
    int32_t den = X1 + (int32_t)bmp_cal.MD;
    if (den == 0) { *temp_c = 0; *press_pa = 0; *alt_m = 0; return; }   /* sensor missing */
    int32_t X2 = ((int32_t)bmp_cal.MC << 11) / den;
    bmp_B5 = X1 + X2;
    *temp_c = (float)((bmp_B5 + 8) >> 4) / 10.0f;

    int32_t B6 = bmp_B5 - 4000;
    X1 = ((int32_t)bmp_cal.B2 * ((B6 * B6) >> 12)) >> 11;
    X2 = ((int32_t)bmp_cal.AC2 * B6) >> 11;
    int32_t X3 = X1 + X2;
    int32_t B3 = (((((int32_t)bmp_cal.AC1 * 4) + X3) << BMP_OSS) + 2) >> 2;

    X1 = ((int32_t)bmp_cal.AC3 * B6) >> 13;
    X2 = ((int32_t)bmp_cal.B1 * ((B6 * B6) >> 12)) >> 16;
    X3 = ((X1 + X2) + 2) >> 2;
    uint32_t B4 = ((uint32_t)bmp_cal.AC4 * (uint32_t)(X3 + 32768)) >> 15;
    uint32_t B7 = ((uint32_t)UP - (uint32_t)B3) * (50000UL >> BMP_OSS);
    if (B4 == 0) { *press_pa = 0; *alt_m = 0; return; }

    int32_t p;
    if (B7 < 0x80000000UL) p = (int32_t)((B7 << 1) / B4);
    else                   p = (int32_t)((B7 / B4) << 1);

    X1 = (p >> 8) * (p >> 8);
    X1 = (X1 * 3038) >> 16;
    X2 = (-7357 * p) >> 16;
    p  = p + ((X1 + X2 + 3791) >> 4);

    *press_pa = (float)p;
    *alt_m = 44330.0f * (1.0f - powf(*press_pa / 101325.0f, 1.0f / 5.255f));
}

/* ═════════════ INA219 (100 ohm shunt, 32 V range) ═════════════ */
static void INA219_Init(void)
{
    I2C_WriteReg16(INA219_ADDR, INA_REG_CONFIG, 0x3FFF);
    I2C_WriteReg16(INA219_ADDR, INA_REG_CALIB,  0x1000);
}

static void INA219_Read(float *voltage, float *current_mA, float *power_mW)
{
    int16_t raw_bus = I2C_ReadReg16(INA219_ADDR, INA_REG_BUS_V);
    int16_t raw_cur = I2C_ReadReg16(INA219_ADDR, INA_REG_CURRENT);
    int16_t raw_pwr = I2C_ReadReg16(INA219_ADDR, INA_REG_POWER);
    *voltage    = (float)(raw_bus >> 3) * 0.004f;
    *current_mA = (float)raw_cur * 0.0001f;
    *power_mW   = (float)raw_pwr * 0.002f;
}

/* ═════════════ MADGWICK ═════════════
   Same math as your working version, but dt is now measured (the old fixed
   10 ms assumed no other code ever blocked the loop). */
static void MadgwickUpdate(float gx, float gy, float gz,
                           float ax, float ay, float az,
                           float mx, float my, float mz, float dt)
{
    float recipNorm, s0, s1, s2, s3, qDot1, qDot2, qDot3, qDot4, hx, hy;
    float _2q0mx, _2q0my, _2q0mz, _2q1mx, _2bx, _2bz, _4bx, _4bz;
    float _2q0, _2q1, _2q2, _2q3;
    float q0q0, q0q1, q0q2, q0q3, q1q1, q1q2, q1q3, q2q2, q2q3, q3q3;

    qDot1 = 0.5f * (-q1*gx - q2*gy - q3*gz);
    qDot2 = 0.5f * ( q0*gx + q2*gz - q3*gy);
    qDot3 = 0.5f * ( q0*gy - q1*gz + q3*gx);
    qDot4 = 0.5f * ( q0*gz + q1*gy - q2*gx);

    if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f)) &&
        !((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f)))
    {
        recipNorm = 1.0f / sqrtf(ax*ax + ay*ay + az*az);
        ax *= recipNorm; ay *= recipNorm; az *= recipNorm;
        recipNorm = 1.0f / sqrtf(mx*mx + my*my + mz*mz);
        mx *= recipNorm; my *= recipNorm; mz *= recipNorm;

        _2q0mx = 2.0f*q0*mx; _2q0my = 2.0f*q0*my; _2q0mz = 2.0f*q0*mz; _2q1mx = 2.0f*q1*mx;
        _2q0 = 2.0f*q0; _2q1 = 2.0f*q1; _2q2 = 2.0f*q2; _2q3 = 2.0f*q3;
        q0q0 = q0*q0; q0q1 = q0*q1; q0q2 = q0*q2; q0q3 = q0*q3;
        q1q1 = q1*q1; q1q2 = q1*q2; q1q3 = q1*q3;
        q2q2 = q2*q2; q2q3 = q2*q3; q3q3 = q3*q3;

        hx = mx*q0q0 - _2q0my*q3 + _2q0mz*q2 + mx*q1q1 + _2q1*my*q2 + _2q1*mz*q3 - mx*q2q2 - mx*q3q3;
        hy = _2q0mx*q3 + my*q0q0 - _2q0mz*q1 + _2q1mx*q2 - my*q1q1 + my*q2q2 + _2q2*mz*q3 - my*q3q3;
        _2bx = sqrtf(hx*hx + hy*hy);
        _2bz = -_2q0mx*q2 + _2q0my*q1 + mz*q0q0 + _2q1mx*q3 - mz*q1q1 + _2q2*my*q3 - mz*q2q2 + mz*q3q3;
        _4bx = 2.0f*_2bx; _4bz = 2.0f*_2bz;

        s0 = -_2q2*(2.0f*(q1q3 - q0q2) - ax) + _2q1*(2.0f*(q0q1 + q2q3) - ay)
           - _2bz*q2*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q3 + _2bz*q1)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q2*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s1 =  _2q3*(2.0f*(q1q3 - q0q2) - ax) + _2q0*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q1*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + _2bz*q3*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q2 + _2bz*q0)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q3 - _4bz*q1)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s2 = -_2q0*(2.0f*(q1q3 - q0q2) - ax) + _2q3*(2.0f*(q0q1 + q2q3) - ay)
           - 4.0f*q2*(1.0f - 2.0f*q1q1 - 2.0f*q2q2 - az)
           + (-_4bx*q2 - _2bz*q0)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (_2bx*q1 + _2bz*q3)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + (_2bx*q0 - _4bz*q2)*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);
        s3 =  _2q1*(2.0f*(q1q3 - q0q2) - ax) + _2q2*(2.0f*(q0q1 + q2q3) - ay)
           + (-_4bx*q3 + _2bz*q1)*(_2bx*(0.5f - q2q2 - q3q3) + _2bz*(q1q3 - q0q2) - mx)
           + (-_2bx*q0 + _2bz*q2)*(_2bx*(q1q2 - q0q3) + _2bz*(q0q1 + q2q3) - my)
           + _2bx*q1*(_2bx*(q0q2 + q1q3) + _2bz*(0.5f - q1q1 - q2q2) - mz);

        recipNorm = 1.0f / sqrtf(s0*s0 + s1*s1 + s2*s2 + s3*s3);
        s0 *= recipNorm; s1 *= recipNorm; s2 *= recipNorm; s3 *= recipNorm;
        qDot1 -= BETA*s0; qDot2 -= BETA*s1; qDot3 -= BETA*s2; qDot4 -= BETA*s3;
    }

    q0 += qDot1*dt; q1 += qDot2*dt; q2 += qDot3*dt; q3 += qDot4*dt;
    recipNorm = 1.0f / sqrtf(q0*q0 + q1*q1 + q2*q2 + q3*q3);
    q0 *= recipNorm; q1 *= recipNorm; q2 *= recipNorm; q3 *= recipNorm;
}

/* 6-axis version (accel + gyro only) */
static void MadgwickUpdateIMU(float gx, float gy, float gz,
                              float ax, float ay, float az, float dt)
{
    float qDot1 = 0.5f * (-q1*gx - q2*gy - q3*gz);
    float qDot2 = 0.5f * ( q0*gx + q2*gz - q3*gy);
    float qDot3 = 0.5f * ( q0*gy - q1*gz + q3*gx);
    float qDot4 = 0.5f * ( q0*gz + q1*gy - q2*gx);
    float n = sqrtf(ax*ax + ay*ay + az*az);
    if (n > 0.3f) {
        ax /= n; ay /= n; az /= n;
        float s0 = 4*q0*q2*q2 + 2*q2*ax + 4*q0*q1*q1 - 2*q1*ay;
        float s1 = 4*q1*q3*q3 - 2*q3*ax + 4*q0*q0*q1 - 2*q0*ay - 4*q1 + 8*q1*q1*q1 + 8*q1*q2*q2 + 4*q1*az;
        float s2 = 4*q0*q0*q2 + 2*q0*ax + 4*q2*q3*q3 - 2*q3*ay - 4*q2 + 8*q2*q1*q1 + 8*q2*q2*q2 + 4*q2*az;
        float s3 = 4*q1*q1*q3 - 2*q1*ax + 4*q2*q2*q3 - 2*q2*ay;
        float sn = sqrtf(s0*s0 + s1*s1 + s2*s2 + s3*s3);
        if (sn > 0) { qDot1 -= BETA*s0/sn; qDot2 -= BETA*s1/sn; qDot3 -= BETA*s2/sn; qDot4 -= BETA*s3/sn; }
    }
    q0 += qDot1*dt; q1 += qDot2*dt; q2 += qDot3*dt; q3 += qDot4*dt;
    n = sqrtf(q0*q0 + q1*q1 + q2*q2 + q3*q3);
    q0 /= n; q1 /= n; q2 /= n; q3 /= n;
}

static void QuaternionToEuler(float *roll, float *pitch, float *yaw)
{
    float sinr_cosp = 2.0f * (q0*q1 + q2*q3);
    float cosr_cosp = 1.0f - 2.0f*(q1*q1 + q2*q2);
    *roll = atan2f(sinr_cosp, cosr_cosp) * 180.0f / (float)M_PI;

    float sinp = 2.0f * (q0*q2 - q3*q1);
    if (fabsf(sinp) >= 1.0f) *pitch = copysignf(90.0f, sinp);
    else                     *pitch = asinf(sinp) * 180.0f / (float)M_PI;

    float siny_cosp = 2.0f * (q0*q3 + q1*q2);
    float cosy_cosp = 1.0f - 2.0f*(q2*q2 + q3*q3);
    *yaw = atan2f(siny_cosp, cosy_cosp) * 180.0f / (float)M_PI;
}

/* ═════════════ BREADBOARD #2 SUPPORT (added Oct 29, 2026) ═════════════
   The original code only knew the HMC5883L (0x1E) and the BMP180. The second
   breadboard has a GY-273 module, which usually carries a QMC5883L at 0x0D,
   and an HW-611 BMP280, which uses different registers and math from the
   BMP180. The functions below check which chips answer at start-up and then
   call the right driver, so the same file runs on both breadboards.        */

#define QMC5883L_ADDR       (0x0D << 1)
#define QMC5883P_ADDR       (0x2C << 1)     /* newer GY-273 chip, NOT supported here */
#define BMP280_ADDR_LO      (0x76 << 1)     /* SDO tied to GND (most HW-611 boards)  */
#define BMP280_ADDR_HI      (0x77 << 1)     /* SDO tied to 3V3; same address as BMP180 */
#define BARO_REG_CHIP_ID    0xD0            /* same register on BMP180 and BMP280    */

/* Hard-iron offsets in uT, in the board axes (after MAG_FX/FY/FZ).
   Leave at 0 for the first log. If the log has the "wave it around" part,
   the offsets can be worked out from it and typed in here.               */
#define MAG_OFS_X           0.0f
#define MAG_OFS_Y           0.0f
#define MAG_OFS_Z           0.0f

typedef enum { MAG_NONE = 0, MAG_HMC5883L, MAG_QMC5883L } MagChip_t;
typedef enum { BARO_NONE = 0, BARO_BMP180, BARO_BMP280 } BaroChip_t;

static MagChip_t  mag_chip  = MAG_NONE;
static BaroChip_t baro_chip = BARO_NONE;
static uint8_t    bmp280_addr = 0;

static uint8_t I2C_Present(uint8_t dev)
{
    return (HAL_I2C_IsDeviceReady(&hi2c1, dev, 2, I2C_TO) == HAL_OK);
}

/* Prints every address that answers, e.g.  "# i2c: 0x0D 0x40 0x68 0x76"
   Expected: 0x0D or 0x1E = magnetometer, 0x40 = INA219, 0x68 = MPU-6050,
             0x76 or 0x77 = BMP280 / BMP180                               */
static void I2C_Scan(void)
{
    printf("# i2c:");
    for (uint8_t a = 0x08; a < 0x78; a++) {
        if (I2C_Present((uint8_t)(a << 1))) printf(" 0x%02X", a);
    }
    printf("\r\n");
}

/* ───────────── QMC5883L (GY-273 / GY-271 modules) ───────────── */
#define QMC_REG_DATA        0x00    /* XL XH YL YH ZL ZH  (low byte first!) */
#define QMC_REG_CTRL1       0x09
#define QMC_REG_CTRL2       0x0A
#define QMC_REG_SETRESET    0x0B
#define QMC_LSB_PER_GAUSS   3000.0f /* +-8 G range                           */

static void QMC5883L_Init(void)
{
    I2C_WriteReg(QMC5883L_ADDR, QMC_REG_CTRL2, 0x80);      /* soft reset                     */
    HAL_Delay(10);
    I2C_WriteReg(QMC5883L_ADDR, QMC_REG_SETRESET, 0x01);   /* value the datasheet asks for   */
    I2C_WriteReg(QMC5883L_ADDR, QMC_REG_CTRL1, 0x1D);      /* OSR 512, +-8 G, 200 Hz, continuous */
}

static void QMC5883L_Read(float *mx, float *my, float *mz)
{
    uint8_t buf[6];
    I2C_ReadBurst(QMC5883L_ADDR, QMC_REG_DATA, buf, 6);

    int16_t rx = (int16_t)((buf[1] << 8) | buf[0]);
    int16_t ry = (int16_t)((buf[3] << 8) | buf[2]);
    int16_t rz = (int16_t)((buf[5] << 8) | buf[4]);

    /* all zero = failed read: keep last good value */
    if (rx == 0 && ry == 0 && rz == 0) {
        *mx = last_mx; *my = last_my; *mz = last_mz;
        return;
    }
    float x = rx / QMC_LSB_PER_GAUSS * 100.0f;     /* -> uT */
    float y = ry / QMC_LSB_PER_GAUSS * 100.0f;
    float z = rz / QMC_LSB_PER_GAUSS * 100.0f;

    float fx = MAG_FX(x, y, z), fy = MAG_FY(x, y, z), fz = MAG_FZ(x, y, z);
    last_mx = *mx = Kalman1D_Update(&mag_kx, fx);
    last_my = *my = Kalman1D_Update(&mag_ky, fy);
    last_mz = *mz = Kalman1D_Update(&mag_kz, fz);
    mag_valid = 1;
}

/* ───────────── BMP280 (HW-611 module) ───────────── */
#define BMP280_REG_CALIB    0x88    /* 24 bytes, low byte first              */
#define BMP280_REG_RESET    0xE0
#define BMP280_REG_CTRL     0xF4
#define BMP280_REG_CONFIG   0xF5
#define BMP280_REG_DATA     0xF7    /* P msb lsb xlsb, T msb lsb xlsb        */

typedef struct {
    uint16_t T1; int16_t T2, T3;
    uint16_t P1; int16_t P2, P3, P4, P5, P6, P7, P8, P9;
} BMP280_Calib_t;
static BMP280_Calib_t b280;

static void BMP280_Init(void)
{
    uint8_t c[24];
    I2C_WriteReg(bmp280_addr, BMP280_REG_RESET, 0xB6);     /* soft reset */
    HAL_Delay(5);
    I2C_ReadBurst(bmp280_addr, BMP280_REG_CALIB, c, 24);
    b280.T1 = (uint16_t)((c[1]  << 8) | c[0]);
    b280.T2 = (int16_t) ((c[3]  << 8) | c[2]);
    b280.T3 = (int16_t) ((c[5]  << 8) | c[4]);
    b280.P1 = (uint16_t)((c[7]  << 8) | c[6]);
    b280.P2 = (int16_t) ((c[9]  << 8) | c[8]);
    b280.P3 = (int16_t) ((c[11] << 8) | c[10]);
    b280.P4 = (int16_t) ((c[13] << 8) | c[12]);
    b280.P5 = (int16_t) ((c[15] << 8) | c[14]);
    b280.P6 = (int16_t) ((c[17] << 8) | c[16]);
    b280.P7 = (int16_t) ((c[19] << 8) | c[18]);
    b280.P8 = (int16_t) ((c[21] << 8) | c[20]);
    b280.P9 = (int16_t) ((c[23] << 8) | c[22]);

    /* config first (writes to it can be ignored in normal mode), then start */
    I2C_WriteReg(bmp280_addr, BMP280_REG_CONFIG, 0x30);    /* 62.5 ms standby, IIR filter x16 */
    I2C_WriteReg(bmp280_addr, BMP280_REG_CTRL,   0x57);    /* temp x2, press x16, normal mode */
}

/* Normal mode: the chip measures on its own, so this is one 6-byte read and
   no HAL_Delay (the BMP180 code blocks the loop for 13 ms every 500 ms).   */
static void BMP280_Read(float *temp_c, float *press_pa, float *alt_m)
{
    uint8_t d[6];
    I2C_ReadBurst(bmp280_addr, BMP280_REG_DATA, d, 6);
    int32_t adc_P = (int32_t)(((uint32_t)d[0] << 12) | ((uint32_t)d[1] << 4) | (d[2] >> 4));
    int32_t adc_T = (int32_t)(((uint32_t)d[3] << 12) | ((uint32_t)d[4] << 4) | (d[5] >> 4));
    if (adc_T == 0 || adc_T == 0x80000) return;            /* failed read / no data yet: keep last */

    /* compensation, integer version from the Bosch BMP280 datasheet */
    int32_t v1 = (((adc_T >> 3) - ((int32_t)b280.T1 << 1)) * (int32_t)b280.T2) >> 11;
    int32_t v2 = (((((adc_T >> 4) - (int32_t)b280.T1) * ((adc_T >> 4) - (int32_t)b280.T1)) >> 12)
                  * (int32_t)b280.T3) >> 14;
    int32_t t_fine = v1 + v2;
    *temp_c = (float)((t_fine * 5 + 128) >> 8) / 100.0f;

    int64_t p1 = (int64_t)t_fine - 128000;
    int64_t p2 = p1 * p1 * (int64_t)b280.P6;
    p2 = p2 + ((p1 * (int64_t)b280.P5) * 131072);          /* << 17 */
    p2 = p2 + ((int64_t)b280.P4 * 34359738368LL);          /* << 35 */
    p1 = ((p1 * p1 * (int64_t)b280.P3) >> 8) + ((p1 * (int64_t)b280.P2) * 4096);   /* << 12 */
    p1 = ((((int64_t)1 << 47) + p1) * (int64_t)b280.P1) >> 33;
    if (p1 == 0) return;                                    /* avoid divide by zero */
    int64_t p = 1048576 - adc_P;
    p = ((p * 2147483648LL - p2) * 3125) / p1;              /* p << 31 */
    int64_t p9 = ((int64_t)b280.P9 * (p >> 13) * (p >> 13)) >> 25;
    int64_t p8 = ((int64_t)b280.P8 * p) >> 19;
    p = ((p + p9 + p8) >> 8) + ((int64_t)b280.P7 * 16);     /* Pa in Q24.8 */

    *press_pa = (float)p / 256.0f;
    *alt_m = 44330.0f * (1.0f - powf(*press_pa / 101325.0f, 1.0f / 5.255f));
}

/* ───────────── pick the right chips at start-up ───────────── */
static void Mag_Init(void)
{
    if (I2C_Present(QMC5883L_ADDR)) {
        mag_chip = MAG_QMC5883L;
        QMC5883L_Init();
        printf("# mag: QMC5883L at 0x0D\r\n");
    } else if (I2C_Present(HMC5883L_ADDR)) {
        mag_chip = MAG_HMC5883L;
        HMC5883L_Init();
        printf("# mag: HMC5883L at 0x1E\r\n");
    } else if (I2C_Present(QMC5883P_ADDR)) {
        printf("# mag: chip at 0x2C (QMC5883P?) - no driver yet, running 6-axis\r\n");
    } else {
        printf("# mag: none found - running 6-axis (yaw will drift)\r\n");
    }
}

static void Mag_Read(float *mx, float *my, float *mz)
{
    if      (mag_chip == MAG_QMC5883L) QMC5883L_Read(mx, my, mz);
    else if (mag_chip == MAG_HMC5883L) HMC5883L_Read(mx, my, mz);
    else return;
    *mx -= MAG_OFS_X; *my -= MAG_OFS_Y; *mz -= MAG_OFS_Z;
}

static void Baro_Init(void)
{
    uint8_t id = 0;
    I2C_ReadBurst(BMP180_ADDR, BARO_REG_CHIP_ID, &id, 1);   /* 0x77 first */
    if (id == 0x55) {
        baro_chip = BARO_BMP180;
        BMP180_Init();
        printf("# baro: BMP180 at 0x77\r\n");
        return;
    }
    /* 0x58 = BMP280, 0x56/0x57 = early BMP280, 0x60 = BME280 (same P/T math) */
    if (id == 0x58 || id == 0x56 || id == 0x57 || id == 0x60) {
        bmp280_addr = BMP280_ADDR_HI;
    } else {
        id = 0;
        I2C_ReadBurst(BMP280_ADDR_LO, BARO_REG_CHIP_ID, &id, 1);
        if (id == 0x58 || id == 0x56 || id == 0x57 || id == 0x60) bmp280_addr = BMP280_ADDR_LO;
    }
    if (bmp280_addr) {
        baro_chip = BARO_BMP280;
        BMP280_Init();
        printf("# baro: %s at 0x%02X\r\n", (id == 0x60) ? "BME280" : "BMP280", bmp280_addr >> 1);
    } else {
        printf("# baro: none found\r\n");
    }
}

static void Baro_Read(float *temp_c, float *press_pa, float *alt_m)
{
    if      (baro_chip == BARO_BMP280) BMP280_Read(temp_c, press_pa, alt_m);
    else if (baro_chip == BARO_BMP180) BMP180_Read(temp_c, press_pa, alt_m);
}
/* ═════════════ END BREADBOARD #2 SUPPORT ═════════════ */


/* ═════════════ FLIGHT CONTROL BENCH BUILD (added Nov 3, 2026) ═════════════
   SBUS input (USART1 RX on PA10, through the 74LS04 inverter), fixed-rate
   400 Hz loop, cascaded PID (Section 3.1.3 of the report), X mixer, arming and
   failsafe, four PWM outputs (TIM3 on PC6-PC9), a loop-timing pin (PB5 = D4),
   and S/C/K/T lines for MK2_PID_Viewer.html.
   BENCH ONLY: no ESCs and no propellers. Gains are starting values, NOT tuned. */

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

/* ───────────── SBUS receiver ─────────────
   SBUS: 100000 baud, 8 data bits, even parity, 2 stop bits, inverted. One frame
   is 25 bytes: 0x0F, 22 bytes holding 16 channels x 11 bits, a flags byte, and an
   end byte. Frames come every 7-14 ms with a quiet gap between them.             */
#define SBUS_FRAME_LEN      25
#define SBUS_FLAG_LOST      0x04    /* receiver missed a frame       */
#define SBUS_FLAG_FAILSAFE  0x08    /* receiver is in failsafe       */

typedef struct {
    uint16_t ch[16];
    uint8_t  flags;
    uint32_t t_ms;                  /* HAL_GetTick() of the last good frame */
    uint32_t frames, errors;
} Sbus_t;

static volatile Sbus_t sbus;
static uint8_t  sbus_buf[SBUS_FRAME_LEN];
static uint8_t  sbus_idx = 0, sbus_bad = 0;
static uint32_t sbus_last_cyc = 0;

/* unpack 16 channels of 11 bits each, low bit first, starting at byte 1 */
static void Sbus_Decode(const uint8_t *f, uint16_t *ch)
{
    uint32_t bits = 0; uint8_t nbits = 0, k = 1;
    for (int c = 0; c < 16; c++) {
        while (nbits < 11) { bits |= (uint32_t)f[k++] << nbits; nbits += 8; }
        ch[c] = (uint16_t)(bits & 0x07FF);
        bits >>= 11; nbits -= 11;
    }
}

static void Sbus_Init(void)                 /* call after the DWT cycle counter is on */
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART1_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_10; g.Mode = GPIO_MODE_AF_PP; g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_HIGH; g.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &g);

    USART1->CR1 = 0;
    USART1->BRR = (HAL_RCC_GetPCLK2Freq() + 50000u) / 100000u;    /* 100000 baud */
    USART1->CR2 = USART_CR2_STOP_1;                               /* 2 stop bits */
    USART1->CR3 = 0;
    /* M = 9-bit word: on the STM32 the parity bit counts as part of the word,
       so 8 data bits + even parity needs M = 1 (PS = 0 means even)              */
    USART1->CR1 = USART_CR1_M | USART_CR1_PCE | USART_CR1_RE | USART_CR1_RXNEIE;
    USART1->CR1 |= USART_CR1_UE;
    HAL_NVIC_SetPriority(USART1_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
}

void USART1_IRQHandler(void)
{
    uint32_t sr = USART1->SR;
    if (!(sr & (USART_SR_RXNE | USART_SR_ORE))) return;
    uint8_t b = (uint8_t)(USART1->DR & 0xFF);       /* reading SR then DR clears the error flags */
    uint32_t now = DWT->CYCCNT;
    if ((now - sbus_last_cyc) > (SystemCoreClock / 1000u) * 2u) { sbus_idx = 0; sbus_bad = 0; }   /* gap > 2 ms: new frame */
    sbus_last_cyc = now;
    if (sr & (USART_SR_PE | USART_SR_FE | USART_SR_NE | USART_SR_ORE)) sbus_bad = 1;
    if (sbus_idx == 0 && b != 0x0F) return;         /* wait for the start byte */
    sbus_buf[sbus_idx++] = b;
    if (sbus_idx == SBUS_FRAME_LEN) {
        uint8_t end = sbus_buf[24];
        if (!sbus_bad && (end == 0x00 || (end & 0x0F) == 0x04)) {
            uint16_t ch[16];
            Sbus_Decode(sbus_buf, ch);
            for (int i = 0; i < 16; i++) sbus.ch[i] = ch[i];
            sbus.flags = sbus_buf[23];
            sbus.t_ms  = HAL_GetTick();
            sbus.frames++;
        } else {
            sbus.errors++;
        }
        sbus_idx = 0; sbus_bad = 0;
    }
}

/* raw SBUS value -> 1000..2000 us (throttle) and -1..+1 (sticks, 2% dead band) */
static float Sbus_ToUs(uint16_t raw)
{
    return clampf(1000.0f + ((float)raw - SBUS_MIN) * 1000.0f / (float)(SBUS_MAX - SBUS_MIN), 1000.0f, 2000.0f);
}
static float Sbus_ToStick(uint16_t raw, int rev)
{
    float s = clampf(((float)raw - SBUS_MID) / (float)(SBUS_MAX - SBUS_MID), -1.0f, 1.0f);
    if (fabsf(s) < 0.02f) s = 0.0f;
    return rev ? -s : s;
}

/* ───────────── motor PWM: TIM3 CH1-CH4 on PC6-PC9 (prototype pins) ─────────────
   The PCB uses TIM2 on PA0-PA3, but on the Nucleo PA2/PA3 are the ST-Link serial
   port, so the prototype uses TIM3. Order: CH1 = FL, CH2 = FR, CH3 = RR, CH4 = RL. */
static void Pwm_Init(void)
{
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_TIM3_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9;
    g.Mode = GPIO_MODE_AF_PP; g.Pull = GPIO_NOPULL; g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOC, &g);

    uint32_t pclk1  = HAL_RCC_GetPCLK1Freq();
    uint32_t timclk = ((RCC->CFGR & RCC_CFGR_PPRE1) == RCC_CFGR_PPRE1_DIV1) ? pclk1 : 2u * pclk1;
    TIM3->CR1   = 0;
    TIM3->PSC   = (uint16_t)(timclk / 1000000u - 1u);       /* 1 count = 1 us */
    TIM3->ARR   = 1000000u / PWM_HZ - 1u;
    TIM3->CCMR1 = (6u << TIM_CCMR1_OC1M_Pos) | TIM_CCMR1_OC1PE | (6u << TIM_CCMR1_OC2M_Pos) | TIM_CCMR1_OC2PE;
    TIM3->CCMR2 = (6u << TIM_CCMR2_OC3M_Pos) | TIM_CCMR2_OC3PE | (6u << TIM_CCMR2_OC4M_Pos) | TIM_CCMR2_OC4PE;
    TIM3->CCR1  = MOTOR_OFF_US; TIM3->CCR2 = MOTOR_OFF_US; TIM3->CCR3 = MOTOR_OFF_US; TIM3->CCR4 = MOTOR_OFF_US;
    TIM3->CCER  = TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC4E;
    TIM3->CR1   = TIM_CR1_ARPE;
    TIM3->EGR   = TIM_EGR_UG;
    TIM3->CR1  |= TIM_CR1_CEN;
}

static void Pwm_Write(const uint16_t m[4])
{
    TIM3->CCR1 = m[0]; TIM3->CCR2 = m[1]; TIM3->CCR3 = m[2]; TIM3->CCR4 = m[3];
}

/* ───────────── loop-timing pin: PB5 (D4), high while the loop is working ───────────── */
#define TIMING_PORT  GPIOB
#define TIMING_PIN   GPIO_PIN_5
#define TIMING_HIGH() (TIMING_PORT->BSRR = TIMING_PIN)
#define TIMING_LOW()  (TIMING_PORT->BSRR = (uint32_t)TIMING_PIN << 16)
static void TimingPin_Init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = TIMING_PIN; g.Mode = GPIO_MODE_OUTPUT_PP; g.Pull = GPIO_NOPULL; g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(TIMING_PORT, &g);
    TIMING_LOW();
}

/* ───────────── PID ─────────────
   Derivative on the measurement (no kick when the setpoint jumps), low-pass
   filtered, and a clamped integral that is held at zero when integrate = 0.      */
typedef struct {
    float kp, ki, kd, out_max, i_max;
    float i, prev_meas, d_lpf;
    float p_term, i_term, d_term;           /* last values, for the viewer */
} Pid_t;

static float Pid_Update(Pid_t *c, float sp, float meas, float dt, uint8_t integrate)
{
    float e = sp - meas;
    c->p_term = c->kp * e;
    if (integrate) c->i = clampf(c->i + c->ki * e * dt, -c->i_max, c->i_max);
    else           c->i = 0.0f;
    c->i_term = c->i;
    float dmeas = (meas - c->prev_meas) / dt;
    c->prev_meas = meas;
    float a = dt / (dt + 1.0f / (2.0f * (float)M_PI * D_LPF_HZ));
    c->d_lpf += a * (dmeas - c->d_lpf);
    c->d_term = -c->kd * c->d_lpf;
    return clampf(c->p_term + c->i_term + c->d_term, -c->out_max, c->out_max);
}

static Pid_t pid_ang_r  = { .kp = ANGLE_KP,   .out_max = RATE_SP_MAX_DPS };
static Pid_t pid_ang_p  = { .kp = ANGLE_KP,   .out_max = RATE_SP_MAX_DPS };
static Pid_t pid_rate_r = { .kp = RATE_RP_KP, .ki = RATE_RP_KI, .kd = RATE_RP_KD, .out_max = UOUT_MAX_RP_US, .i_max = I_MAX_US };
static Pid_t pid_rate_p = { .kp = RATE_RP_KP, .ki = RATE_RP_KI, .kd = RATE_RP_KD, .out_max = UOUT_MAX_RP_US, .i_max = I_MAX_US };
static Pid_t pid_rate_y = { .kp = RATE_Y_KP,  .ki = RATE_Y_KI,  .kd = RATE_Y_KD,  .out_max = UOUT_MAX_Y_US,  .i_max = I_MAX_US };

/* ───────────── X mixer (Section 3.1.3 of the report) ─────────────
   uR  = roll effort  (+ = roll right, right side down)
   uPu = pitch effort (+ = nose UP, the same sign as the report's equations)
   uY  = yaw effort   (+ = speed up the front-right / rear-left pair)
   If a motor would go past its limits, the differences between motors are kept
   and some throttle is given up. Output order: FL, FR, RR, RL.                    */
static void Mixer(float T, float uR, float uPu, float uY, uint16_t out[4])
{
    float mix[4] = {
        +uR + uPu - uY,                     /* FL */
        -uR + uPu + uY,                     /* FR */
        -uR - uPu - uY,                     /* RR */
        +uR - uPu + uY                      /* RL */
    };
    float hi = mix[0], lo = mix[0];
    for (int i = 1; i < 4; i++) { if (mix[i] > hi) hi = mix[i]; if (mix[i] < lo) lo = mix[i]; }
    float room = (float)(MOTOR_MAX_US - MOTOR_IDLE_US);
    if (hi - lo > room) {                   /* corrections too big: shrink them all */
        float s = room / (hi - lo);
        for (int i = 0; i < 4; i++) mix[i] *= s;
        hi *= s; lo *= s;
    }
    T = clampf(T, (float)MOTOR_IDLE_US - lo, (float)MOTOR_MAX_US - hi);
    for (int i = 0; i < 4; i++) out[i] = (uint16_t)(T + mix[i] + 0.5f);
}

/* ───────────── arming ─────────────
   Arms only when the arm switch goes from low to high while the RC link is good,
   the throttle is at the bottom, and the board is level enough. A switch that is
   already high at power-on (or when the link comes back) has to be cycled first.
   Disarms on: switch low, failsafe or lost link, or tilt past the cutoff.        */
enum { REASON_NONE = 0, REASON_SWITCH = 1, REASON_LINK = 2, REASON_TILT = 3, REASON_IMU = 4 };
static uint8_t armed = 0, arm_sw_prev = 1, disarm_reason = REASON_NONE;

static void Arm_Update(uint8_t link_ok, uint8_t sw, float thr_us, float roll, float pitch)
{
    uint8_t tilted = (fabsf(roll) > TILT_CUTOFF_DEG) || (fabsf(pitch) > TILT_CUTOFF_DEG);
    if (armed) {
        if      (!link_ok) { armed = 0; disarm_reason = REASON_LINK; }
        else if (!sw)      { armed = 0; disarm_reason = REASON_SWITCH; }
        else if (tilted)   { armed = 0; disarm_reason = REASON_TILT; }
    } else if (link_ok && sw && !arm_sw_prev && thr_us < THR_ARM_MAX_US && !tilted) {
        armed = 1; disarm_reason = REASON_NONE;
    }
    arm_sw_prev = link_ok ? sw : 1;         /* no link: act as if the switch is high */
}

/* ───────────── viewer lines ─────────────
   S,ch1..ch8,flags,link
   C,armed,reason,thr,roll_sp,pitch_sp,yawrate_sp,roll,pitch,rate_sp_r,rate_sp_p,
     gx,gy,gz,u_r,u_p,u_y,m_FL,m_FR,m_RR,m_RL
   K,P_r,I_r,D_r,P_p,I_p,D_p,P_y,I_y,D_y        (inner rate loops)
   T,loop_hz,avg_us,max_us,overruns,sbus_fps,sbus_err,tx_drops                   */
typedef struct {
    uint8_t  armed, reason, link;
    float    thr, sp_r, sp_p, sp_y, roll, pitch, rsp_r, rsp_p, gx, gy, gz, u_r, u_p, u_y;
    uint16_t m[4];
} Ctl_t;

static char *put_c(char *p, float v, int dec) { *p++ = ','; return put_fixed(p, v, dec); }

__attribute__((unused)) static void Send_S(const uint16_t ch[16], uint8_t flags, uint8_t link)
{
    char b[80], *p = b;
    *p++ = 'S';
    for (int i = 0; i < 8; i++) p = put_c(p, (float)ch[i], 0);
    p = put_c(p, (float)flags, 0); p = put_c(p, (float)link, 0); *p++ = '\n';
    uart_send(b, (uint16_t)(p - b));
}

__attribute__((unused)) static void Send_C(const Ctl_t *c)
{
    char b[176], *p = b;
    *p++ = 'C';
    p = put_c(p, c->armed, 0); p = put_c(p, c->reason, 0); p = put_c(p, c->thr, 0);
    p = put_c(p, c->sp_r, 1);  p = put_c(p, c->sp_p, 1);   p = put_c(p, c->sp_y, 1);
    p = put_c(p, c->roll, 1);  p = put_c(p, c->pitch, 1);
    p = put_c(p, c->rsp_r, 1); p = put_c(p, c->rsp_p, 1);
    p = put_c(p, c->gx, 1);    p = put_c(p, c->gy, 1);     p = put_c(p, c->gz, 1);
    p = put_c(p, c->u_r, 1);   p = put_c(p, c->u_p, 1);    p = put_c(p, c->u_y, 1);
    for (int i = 0; i < 4; i++) p = put_c(p, c->m[i], 0);
    *p++ = '\n';
    uart_send(b, (uint16_t)(p - b));
}

__attribute__((unused)) static void Send_K(const Pid_t *r, const Pid_t *pp, const Pid_t *y)
{
    char b[112], *p = b;
    const Pid_t *a[3] = { r, pp, y };
    *p++ = 'K';
    for (int i = 0; i < 3; i++) { p = put_c(p, a[i]->p_term, 1); p = put_c(p, a[i]->i_term, 1); p = put_c(p, a[i]->d_term, 1); }
    *p++ = '\n';
    uart_send(b, (uint16_t)(p - b));
}

__attribute__((unused)) static void Send_T(float loop_hz, float avg_us, float max_us, uint32_t overruns, float sbus_fps, uint32_t sbus_err, uint32_t drops)
{
    char b[96], *p = b;
    *p++ = 'T';
    p = put_c(p, loop_hz, 1); p = put_c(p, avg_us, 0); p = put_c(p, max_us, 0);
    p = put_c(p, (float)overruns, 0); p = put_c(p, sbus_fps, 1); p = put_c(p, (float)sbus_err, 0); p = put_c(p, (float)drops, 0);
    *p++ = '\n';
    uart_send(b, (uint16_t)(p - b));
}
/* ═════════════ END FLIGHT CONTROL BENCH BUILD ═════════════ */
/* USER CODE END 0 */

int main(void)
{
    /* USER CODE BEGIN 1 */
    /* USER CODE END 1 */

    HAL_Init();

    /* USER CODE BEGIN Init */
    /* USER CODE END Init */

    SystemClock_Config();

    /* USER CODE BEGIN SysInit */
    /* USER CODE END SysInit */

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART2_UART_Init();

    /* USER CODE BEGIN 2 */
    /* microsecond-accurate timer for the filter's dt */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;

    UART_TxInit();                  /* non-blocking serial output from here on      */
    Pwm_Init();                     /* motor outputs start at MOTOR_OFF_US (1000 us) */
    TimingPin_Init();

    printf("\r\n# MK2 sensor fusion + flight control bench build (no ESCs, no props)\r\n");
    if (HAL_I2C_IsDeviceReady(&hi2c1, (0x68 << 1), 2, I2C_TO) != HAL_OK &&
        HAL_I2C_IsDeviceReady(&hi2c1, (0x69 << 1), 2, I2C_TO) == HAL_OK) { mpu_addr = (0x69 << 1); printf("# MPU-6050 found at 0x69 (AD0 is high)\r\n"); }
    MPU6050_Init();
    I2C_Scan();
    Mag_Init();
    Baro_Init();
    INA219_Init();

    /* sanity check: MPU WHO_AM_I */
    {
        uint8_t id = 0;
        I2C_ReadBurst(MPU6050_ADDR, 0x75, &id, 1);
        if (id == 0) printf("# ERROR: MPU-6050 not responding (check PB8/PB9, 3V3, GND)\r\n");
        else         printf("# MPU-6050 ok (WHO_AM_I=0x%02X)\r\n", id);
    }

    printf("# keep the board still: calibrating gyro...\r\n");
    {
        float ax, ay, az, gx, gy, gz, t, sx = 0, sy = 0, sz = 0;
        int good = 0;
        for (int i = 0; i < GYRO_CAL_SAMPLES; i++) {
            if (MPU6050_Read(&ax, &ay, &az, &gx, &gy, &gz, &t)) { sx += gx; sy += gy; sz += gz; good++; }
            HAL_Delay(4);
        }
        if (good > GYRO_CAL_SAMPLES / 2) { gbias_x = sx / good; gbias_y = sy / good; gbias_z = sz / good; }
        printf("# gyro calibration: %d of %d reads good, bias %d %d %d (0.01 deg/s)\r\n", good, GYRO_CAL_SAMPLES,
               (int)(gbias_x * 5729.578f), (int)(gbias_y * 5729.578f), (int)(gbias_z * 5729.578f));
        if (good <= GYRO_CAL_SAMPLES / 2) printf("# ERROR: MPU-6050 reads are failing; check SDA/SCL wires and 3V3\r\n");
    }
    Sbus_Init();
    printf("# control: %d Hz loop, outer loop %d Hz, PWM %d Hz on PC6-PC9, SBUS on PA10 (D2), timing pin PB5 (D4)\r\n",
           LOOP_HZ, LOOP_HZ / OUTER_DIV, PWM_HZ);
    printf("# ready\r\n");

    float ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0, imu_temp = 0;
    float gx_raw = 0, gy_raw = 0, gz_raw = 0;
    uint32_t imu_bad = 0, imu_fail_total = 0, imu_recoveries = 0, imu_recover_ms = 0;
    float mx = 0, my = 0, mz = 0;
    float bmp_temp = 0, pressure = 0, altitude = 0;
    float bus_v = 0, current_mA = 0, power_mW = 0;
    float roll = 0, pitch = 0, yaw = 0;

    Ctl_t    ctl = {0};
    uint16_t ch[16] = {0};
    uint8_t  sb_flags = 0;
    uint32_t sb_t = 0, sb_frames = 0, sb_errors = 0, sb_frames_prev = 0;
    float    rate_sp_r = 0, rate_sp_p = 0;
    const float dt_ctl   = 1.0f / (float)LOOP_HZ;
    const float dt_outer = (float)OUTER_DIV / (float)LOOP_HZ;

    /* loop-timing statistics, reported twice a second on the T line */
    const uint32_t period = SystemCoreClock / LOOP_HZ;
    const float    cyc_per_us = (float)SystemCoreClock / 1.0e6f;
    uint32_t next = DWT->CYCCNT + period, tick = 0;
    uint32_t st_sum = 0, st_max = 0, st_n = 0, overruns = 0, st_t0 = HAL_GetTick();
    (void)ctl; (void)sb_errors; (void)sb_frames_prev; (void)cyc_per_us; (void)st_t0;   /* unused when STREAM_CONTROL = 0 */
    last_cyc = DWT->CYCCNT;
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* ── wait for the next 2.5 ms slot (fixed-rate loop) ── */
        while ((int32_t)(DWT->CYCCNT - next) < 0) { }
        uint32_t t_start = DWT->CYCCNT;
        if ((int32_t)(t_start - next) > (int32_t)period) next = t_start;   /* fell far behind: resync */
        next += period;
        TIMING_HIGH();

        /* ── sensors and attitude filter ── */
        if (MPU6050_Read(&ax, &ay, &az, &gx_raw, &gy_raw, &gz_raw, &imu_temp)) {
            imu_bad = 0;
            gx = gx_raw - gbias_x; gy = gy_raw - gbias_y; gz = gz_raw - gbias_z;
        } else {
            /* Failed read: keep the last sample. After 8 in a row, free the I2C bus and
               wake the MPU-6050 again. If that keeps happening at 400 kHz, drop to 100 kHz. */
            imu_fail_total++;
            if (++imu_bad >= 8 && (HAL_GetTick() - imu_recover_ms) > 1000) {
                imu_recover_ms = HAL_GetTick();
                if (++imu_recoveries >= 3 && i2c_speed_hz > 100000) { i2c_speed_hz = 100000; imu_recoveries = 0; }
                I2C_BusRecover();

                /* Diagnose: which lines are stuck, and which devices answer right now. */
                static const uint8_t known[] = { 0x68, 0x69, 0x0D, 0x1E, 0x2C, 0x40, 0x76, 0x77 };
                uint8_t found[8] = {0}, nfound = 0, at68 = 0, at69 = 0;
                if (i2c_sda_idle && i2c_scl_idle) {
                    for (unsigned i = 0; i < sizeof known; i++) {
                        if (HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(known[i] << 1), 1, 3) == HAL_OK) {
                            found[nfound++] = known[i];
                            if (known[i] == 0x68) at68 = 1;
                            if (known[i] == 0x69) at69 = 1;
                        }
                    }
                }
                if (at69 && !at68) mpu_addr = (0x69 << 1);       /* AD0 is high: use the other address */
                if (at68)          mpu_addr = (0x68 << 1);
                I2C_WriteReg(MPU6050_ADDR, MPU_REG_PWR_MGMT_1, 0x00);
                I2C_WriteReg(MPU6050_ADDR, MPU_REG_SMPLRT_DIV, 0x01);
                I2C_WriteReg(MPU6050_ADDR, MPU_REG_CONFIG,     0x03);
                I2C_WriteReg(MPU6050_ADDR, MPU_REG_GYRO_CFG,   0x08);
                I2C_WriteReg(MPU6050_ADDR, MPU_REG_ACCEL_CFG,  0x00);

                static const char hx[] = "0123456789ABCDEF";
                char b[200], *p = b;
                p = put_str(p, "# IMU FAIL: SDA="); *p++ = i2c_sda_idle ? 'H' : 'L';
                p = put_str(p, " SCL=");            *p++ = i2c_scl_idle ? 'H' : 'L';
                p = put_str(p, " answering:");
                for (unsigned i = 0; i < nfound; i++) { p = put_str(p, " 0x"); *p++ = hx[found[i] >> 4]; *p++ = hx[found[i] & 15]; }
                if (!nfound) p = put_str(p, " none");
                p = put_str(p, " => ");
                if (!i2c_sda_idle || !i2c_scl_idle)
                    p = put_str(p, "a bus wire is held LOW: shorted to GND, or a module is holding it. Unplug modules one at a time.");
                else if (at68 || at69)
                    p = put_str(p, "MPU answers but data reads fail: loose SDA/SCL wire or weak power.");
                else if (nfound)
                    p = put_str(p, "bus works but no MPU-6050: check ITS VCC, GND, SDA and SCL wires.");
                else
                    p = put_str(p, "nothing on the bus: SDA must reach D14 and SCL D15, and the sensors need 3V3 and GND.");
                *p++ = '\n';
                uart_send(b, (uint16_t)(p - b));
                next = DWT->CYCCNT + period; last_cyc = DWT->CYCCNT;
            }
        }
        if (tick % 6 == 3 && imu_bad == 0) Mag_Read(&mx, &my, &mz);   /* every 15 ms */

        uint32_t cyc = DWT->CYCCNT;
        float dt = (float)(cyc - last_cyc) / (float)SystemCoreClock;
        last_cyc = cyc;
        if (dt <= 0.0f || dt > 0.1f) dt = dt_ctl;
#if USE_MAG
        if (mag_valid) MadgwickUpdate(gx, gy, gz, ax, ay, az, mx, my, mz, dt);
        else           MadgwickUpdateIMU(gx, gy, gz, ax, ay, az, dt);
#else
        MadgwickUpdateIMU(gx, gy, gz, ax, ay, az, dt);
#endif
        QuaternionToEuler(&roll, &pitch, &yaw);

        /* ── RC input: copy the latest SBUS frame (interrupts off so it can't change mid-copy) ── */
        __disable_irq();
        for (int i = 0; i < 16; i++) ch[i] = sbus.ch[i];
        sb_flags = sbus.flags; sb_t = sbus.t_ms; sb_frames = sbus.frames; sb_errors = sbus.errors;
        __enable_irq();
        uint8_t link_ok = (sb_frames > 0) && ((HAL_GetTick() - sb_t) < SBUS_TIMEOUT_MS) && !(sb_flags & SBUS_FLAG_FAILSAFE);

        float thr = MOTOR_OFF_US, sp_r = 0, sp_p = 0, sp_y = 0;
        if (link_ok) {
            thr  = Sbus_ToUs(ch[CH_THR]);
            sp_r =  Sbus_ToStick(ch[CH_ROLL],  REV_ROLL)  * MAX_ANGLE_DEG;      /* stick right = right side down */
            sp_p =  Sbus_ToStick(ch[CH_PITCH], REV_PITCH) * MAX_ANGLE_DEG;      /* stick forward = nose down     */
            sp_y = -Sbus_ToStick(ch[CH_YAW],   REV_YAW)   * MAX_YAW_RATE_DPS;   /* stick right = turn clockwise  */
        }
        Arm_Update(link_ok, ch[CH_ARM] > SBUS_MID, thr, roll, pitch);
        if (imu_bad >= 8) { armed = 0; disarm_reason = REASON_IMU; }   /* no attitude data: motors off */

        /* ── cascaded PID: outer angle loop at 100 Hz, inner rate loops at 400 Hz ── */
        float gxd = gx * 57.29578f, gyd = gy * 57.29578f, gzd = gz * 57.29578f;   /* deg/s */
        if (tick % OUTER_DIV == 0) {
            rate_sp_r = Pid_Update(&pid_ang_r, sp_r, roll,  dt_outer, 0);
            rate_sp_p = Pid_Update(&pid_ang_p, sp_p, pitch, dt_outer, 0);
        }
        uint8_t flying = armed && (thr >= THR_ACTIVE_US);
        float u_r = Pid_Update(&pid_rate_r, rate_sp_r, gxd, dt_ctl, flying);
        float u_p = Pid_Update(&pid_rate_p, rate_sp_p, gyd, dt_ctl, flying);
        float u_y = Pid_Update(&pid_rate_y, sp_y,      gzd, dt_ctl, flying);

        /* ── mixer and motor outputs ── */
        uint16_t m[4];
        if (!armed)       { for (int i = 0; i < 4; i++) m[i] = MOTOR_OFF_US; }
        else if (!flying) { for (int i = 0; i < 4; i++) m[i] = MOTOR_IDLE_US; }
        else Mixer(thr, u_r, -u_p, (float)YAW_SIGN * u_y, m);   /* -u_p: our pitch is nose-down positive */
        Pwm_Write(m);

        /* ── slow sensors, spread over different passes ── */
        if (tick % 200 == 50) {
            Baro_Read(&bmp_temp, &pressure, &altitude);
#if !DEBUG_PRINT
            char b[48], *p = b;
            p = put_str(p, "B,"); p = put_fixed(p, pressure / 100.0f, 2); *p++ = ','; p = put_fixed(p, bmp_temp, 1); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
#endif
        }
        if (tick % 200 == 150) {
            INA219_Read(&bus_v, &current_mA, &power_mW);
#if !DEBUG_PRINT
            char b[24], *p = b;
            p = put_str(p, "V,"); p = put_fixed(p, bus_v, 2); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
#endif
        }

        /* ── stream to the viewers ── */
#if DEBUG_PRINT
        if (tick % 80 == 0)
            printf("Roll %7.2f Pitch %7.2f Yaw %7.2f | thr %4d armed %d | m %4d %4d %4d %4d\r\n",
                   roll, pitch, yaw, (int)thr, armed, m[0], m[1], m[2], m[3]);
#else
        if (tick % 13 == 0) {                                          /* attitude, ~30 Hz */
            char b[48], *p = b;
            p = put_str(p, "A,"); p = put_fixed(p, roll, 2); *p++ = ','; p = put_fixed(p, pitch, 2); *p++ = ','; p = put_fixed(p, yaw, 2); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
        }
        if (tick % 13 == 6) {                                          /* raw sensors, ~30 Hz */
            char b[112], *p = b;
            p = put_str(p, "R,");
            p = put_fixed(p, ax, 3); *p++ = ','; p = put_fixed(p, ay, 3); *p++ = ','; p = put_fixed(p, az, 3); *p++ = ',';
            p = put_fixed(p, gxd, 1); *p++ = ','; p = put_fixed(p, gyd, 1); *p++ = ','; p = put_fixed(p, gzd, 1); *p++ = ',';
            p = put_fixed(p, mx, 1); *p++ = ','; p = put_fixed(p, my, 1); *p++ = ','; p = put_fixed(p, mz, 1); *p++ = '\n';
            uart_send(b, (uint16_t)(p - b));
        }
#if STREAM_CONTROL
        if (tick % 20 == 2) Send_S(ch, sb_flags, link_ok);             /* 20 Hz */
        if (tick % 20 == 9) {
            ctl.armed = armed; ctl.reason = disarm_reason; ctl.link = link_ok;
            ctl.thr = thr; ctl.sp_r = sp_r; ctl.sp_p = sp_p; ctl.sp_y = sp_y;
            ctl.roll = roll; ctl.pitch = pitch; ctl.rsp_r = rate_sp_r; ctl.rsp_p = rate_sp_p;
            ctl.gx = gxd; ctl.gy = gyd; ctl.gz = gzd; ctl.u_r = u_r; ctl.u_p = u_p; ctl.u_y = u_y;
            for (int i = 0; i < 4; i++) ctl.m[i] = m[i];
            Send_C(&ctl);
        }
        if (tick % 20 == 16) Send_K(&pid_rate_r, &pid_rate_p, &pid_rate_y);
        if (tick % 200 == 100) {                                       /* loop timing, 2 Hz */
            uint32_t now_ms = HAL_GetTick();
            float secs = (float)(now_ms - st_t0) / 1000.0f;
            if (secs > 0.0f && st_n > 0)
                Send_T((float)st_n / secs, (float)st_sum / (float)st_n / cyc_per_us, (float)st_max / cyc_per_us,
                       overruns, (float)(sb_frames - sb_frames_prev) / secs, sb_errors, tx_drops);
            st_sum = 0; st_max = 0; st_n = 0; overruns = 0; st_t0 = now_ms; sb_frames_prev = sb_frames;
        }
#endif
#endif

        /* ── how long this pass took ── */
        TIMING_LOW();
        uint32_t used = DWT->CYCCNT - t_start;
        st_sum += used; st_n++;
        if (used > st_max) st_max = used;
        if (used > period) overruns++;
        tick++;
        /* USER CODE END WHILE */
    }
    /* USER CODE BEGIN 3 */
    /* USER CODE END 3 */
}

/* SYSTEM CLOCK (180 MHz via PLL on HSI) */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState       = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM       = 8;
    RCC_OscInitStruct.PLL.PLLN       = 180;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 4;
    RCC_OscInitStruct.PLL.PLLR       = 2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();
    if (HAL_PWREx_EnableOverDrive() != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) Error_Handler();
}

/* I2C1 (SCL=PB8, SDA=PB9, 100 kHz) */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance             = I2C1;
    hi2c1.Init.ClockSpeed      = i2c_speed_hz;
    hi2c1.Init.DutyCycle       = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1     = 0;
    hi2c1.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2     = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) Error_Handler();
    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK) Error_Handler();
    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK) Error_Handler();
}

/* USART2 (PA2=TX, PA3=RX, 115200 8N1) */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

void Error_Handler(void)
{
    __disable_irq();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_5; g.Mode = GPIO_MODE_OUTPUT_PP; g.Pull = GPIO_NOPULL; g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &g);
    while (1) { HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); for (volatile uint32_t i = 0; i < 4000000; i++) { } }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) { (void)file; (void)line; }
#endif
